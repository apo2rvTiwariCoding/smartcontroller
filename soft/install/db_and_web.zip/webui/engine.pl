#!c:/xampp/perl/bin/perl.exe

use DBI;
use POSIX;
use Digest::MD5 qw(md5 md5_hex md5_base64);
use Time::Local;
use strict;

# get current datetime

my ($cursec,$curmin,$curhour,$curday,$curmon,$curyear) = (localtime)[0,1,2,3,4,5];
my $loadtime = time();
$curmon ++;
$curday = sprintf("%02d",$curday);
$curmon = sprintf("%02d",$curmon);
$cursec = sprintf("%02d",$cursec);
$curmin = sprintf("%02d",$curmin);
$curhour = sprintf("%02d",$curhour);
$curyear += 1900;
my $curdatetime = "$curyear-$curmon-$curday $curhour:$curmin:$cursec";
my $curampm = 1;
if ($curhour > 11) {
	$curampm ++;	# 1 - AM, 2 - PM
}
my @monthtxt = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
my @ampmtxt = ("am","pm");

# Get data from memory

my %FORM = ();
my $submeth = "post";
my $forlog = "";
unless (exists($FORM{"testnoenv"})) {
	my $bufer = "";
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $bufer, $ENV{'CONTENT_LENGTH'});
		$submeth = "post";
	} else {
		$bufer=$ENV{'QUERY_STRING'};
		$submeth = "get";
	}

	my @pairs = split(/&/, $bufer);

	foreach my $pair (@pairs)
	{
		my ($name, $value) = split(/=/, $pair);
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ s/[\\\'\"\`\%]/\ /g;
		$FORM{$name} = $value;
		$forlog .= "$curdatetime : $name - $value\n";
	}
}

# get server data

my $selfpath = $ENV{'PATH_TRANSLATED'};
$selfpath =~ s/\\[^\\]*$/\\/;
if ($selfpath eq "") {
	$selfpath = $ENV{'SCRIPT_FILENAME'};
	$selfpath =~ s/\/[^\/]*$/\//;
}
my $templateweb = $selfpath."template.html";
my $loginweb = $selfpath."login.html";

# read config

my %config = ();
my $confile = $selfpath."settings.cnf";
if (-e $confile) {
	open(INF,$confile);
	while(<INF>) {
		my $inline = $_;
		chomp($inline);
		if ($inline =~ m/^[a-zA-Z]+/) {
			my ($name,$value) = split(/\=/,$inline);
			$name =~ s/^[\s\t]*//;
			$value =~ s/^[\s\t]*//;
			$name =~ s/[\s\t]*$//;
			$value =~ s/[\s\t]*$//;
			$config{lc($name)} = $value;
		}
	}
	close(INF);
}

# constants from config

my $version = (exists $config{version})?$config{version}:"14.4.14p";
my $debugmode = (exists $config{debug})?$config{debug}:0;		# simulation mode off by default
my $advmode = (exists $config{advanced})?$config{advanced}:1;		# corrections allowed
my $logpath = (exists $config{logpath})?$config{logpath}:"./";		# path for storing logs and private files

# hardcoded constants and moar

my @months = ("Ololo","January","February","March","April","May","June","July","August","September","October","November","December");
my @smonths = ("Ololo","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
my @ampms = ("USSR","AM","PM");
my $exitstatus = 0;				# status to exit to login page
my $sessid = -1;
my $clientip = $ENV{'REMOTE_ADDR'};
my $clientie = $ENV{'HTTP_USER_AGENT'};
my $username = $FORM{user};
my $password = $FORM{pass};
my $userhash = md5_hex($clientip."azze2014".$clientie);
my $cookname = "";
my $rcvd_cookies = $ENV{'HTTP_COOKIE'};
my @cookies = split /;/, $rcvd_cookies;
my $saveduser = "";
my $cusermode = 0;
my $homeid = 0;
foreach my $cookie (@cookies) {
	if ($cookie =~ "icsession2014") {
		($cookname,$sessid) = split(/\=/,$cookie);
	}
	if ($cookie =~ "icuser2014") {
		($cookname,$saveduser) = split(/\=/,$cookie);
	}
	if ($cookie =~ "usermode2014") {
		($cookname,$cusermode) = split(/\=/,$cookie);
	}
	if ($cookie =~ "ichomeid2014") {
		($cookname,$homeid) = split(/\=/,$cookie);
		$homeid += 0;
	}
}
my $signtime = 60;		# time in minutes to stay logged in
my $contents = "";
my $bodyadd = "";
my $headadd = "";
my $debug = "";
my $message = "";
my $servname = $ENV{'SERVER_NAME'};
my $servport = $ENV{'SERVER_PORT'};
my $servprot = ($ENV{'HTTPS'} eq "on")?"https":"http";
unless (($servport eq "80") || ($servport eq "443")) {
	$servname .= ":".$servport;
}
my $foldname = "";
if ($ENV{'SCRIPT_NAME'} =~ /^\/(.+\/)*(.+)\.(.+)$/) {
	$foldname = $1;	
}
$forlog .= "$curdatetime : $clientip - $clientie\n";
my $loffweb = $servprot."://".$servname."/";

# get mode and action

my $savelogin = ($FORM{save_login} eq "yes")?"yes":"no";
my $uimode = (exists $FORM{mode})?$FORM{mode}:"";
my $uismode = (exists $FORM{submode})?$FORM{submode}:"";
my $action = (exists $FORM{action})?$FORM{action}:"";

# connect to mysql

my $dsn = 'DBI:mysql:'.((exists $config{dbname})?$config{dbname}:(($homeid > 0)?(sprintf("smart%05d",$homeid)):"smart")).":".((exists $config{dbhost})?$config{dbhost}:"localhost");
my $db_user_name = (exists $config{dbuser})?$config{dbuser}:(($homeid > 0)?(sprintf("dbuser%05d",$homeid)):"dbuser");
my $db_password = (exists $config{dbpass})?$config{dbpass}:(($homeid > 0)?(sprintf("dbpass%05d",$homeid)):"dbpass");
my $db = DBI->connect($dsn, $db_user_name, $db_password);
if (! $db) {
	($username, $password, $FORM{mode}, $FORM{submode}, $uimode, $uismode) = ("", "", "", "", "", "");
	$exitstatus = 7;
}

# Session creator

my $clientid = -1;
my $clientacc = 0;
my $tempdbid = 0;
if (($username ne "") && ($password ne "") && ($submeth eq "post") && ($action eq "login")) {
	my $sth = $db->prepare("select id,access,login from users where login='$username' and password='$password'");
	$sth->execute;
	unless ($sth->rows == 0) {
		my ($id,$access,$login) = $sth->fetchrow_array();
		if (($access == 1) || ($access == 0)) {			# simple user or integrator
			$clientid = $id;
			$clientacc = $access;
		} elsif ($access == 2) {				# system super admin
			$clientid = $id;
			$clientacc = $access;
		}
		$sth->finish;
	} else {
		$sth->finish;
	}

	if ($clientid >= 0) {
		$db->do("INSERT INTO sessions VALUES(NULL,$clientid,'$userhash',now(),date_add(now(),interval $signtime minute),$clientacc,0)");
		$sth = $db->prepare("SELECT last_insert_id() FROM sessions");
		$sth->execute;
		($sessid) = $sth->fetchrow_array();
		$sth->finish;
	}

	my $fut_time = gmtime(time() + (60 * 60 * 24 * 30))." GMT";  	# cookie expires in 30 days
	my $cookie = "icsession2014=$sessid; path=/; expires=$fut_time;";
	print "Set-Cookie: " . $cookie . "\n";
	if (exists $FORM{savelogin}) {
		$cookie = "icuser2014=$username; path=/; expires=$fut_time;";
		print "Set-Cookie: " . $cookie . "\n";
	}
}

# Session checker

my $ulogin = "";
my $uaccess = 0;
my $sessionnow = 0;
my $sth = $db->prepare("SELECT id_session,id_client,type,dbid FROM sessions WHERE id_session=$sessid AND hash='$userhash' AND expires>NOW()");
$sth->execute;
unless ($sth->rows == 0) {
	my ($sessid,$clid,$clientacc,$odbid) = $sth->fetchrow_array();
	$sth->finish;
	$db->do("UPDATE sessions SET expires=DATE_ADD(expires,INTERVAL $signtime MINUTE) WHERE id_session=$sessid");
	$sessionnow = $sessid;

	$sth = $db->prepare("select login,access from users where id=$clid");
	$sth->execute;
	unless ($sth->rows == 0) {
		my ($login,$access) = $sth->fetchrow_array();
		if ($access == 1) {
			$ulogin = $login;
			$uaccess = $access;
			$clientid = $clid;
		} elsif ($access == 2) {
			$ulogin = $login;
			$uaccess = 1;			# granting admin access to system
			$clientid = $clid;
		} elsif ($access == 0) {
			$ulogin = $login;
			$uaccess = $access;
			$clientid = $clid;
		}
	}
	$sth->finish;
} else {
	$clientid = -1;
	$sth->finish;
}

if ($clientid < 0) {
# if (($clientid < 0) && ($action eq "login")) {
	($password, $uimode, $uismode) = ("", "", "");
	$exitstatus = 1;
}
if (($clientid >= 0) && (($uimode eq "") || ($uismode eq ""))) {
	($uimode, $uismode) = ("status", "relays");			# default page after login
}

# read HVAC config for system

my %HVAC = ();
{
	my $all = $db->selectall_arrayref("SELECT option_,value_ FROM hvac WHERE submenu > 0");		# read HVAC config for system only
	foreach my $row (@$all) {
		my ($opt, $val) = @$row;
		$HVAC{$opt} = $val;
	}
}
if (exists $HVAC{"system.sw_version"}) {
	$version = $HVAC{"system.sw_version"};
}

# menu & submenu processing

my $mainmenu = "";
my $submenu = "";
my $pagetitle = "ASE 2014 Web UI ";
my %alevel = ();
if ($uimode ne "") {
	my $all = $db->selectall_arrayref("SELECT id, menu, submenu, description, access, level FROM ui_menu WHERE level = 0 OR (menu = '$uimode' AND level = 1) ORDER BY id");	# get all main + current sub
	foreach my $row (@$all) {
		my ($meid, $imenu, $isubm, $idesc, $iacc, $mlevel) = @$row;
		$alevel{$imenu.$isubm} = $iacc;
		if ($uaccess >= $iacc) {				# show only if access allowed
			if ($mlevel == 0) {
				if ($imenu eq $uimode) {
					$mainmenu .= "<td><div id=\"div_maintab_".$meid."\" class=\"MainTab\"><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL10\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL11\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL12\"></div></a><a class=\"MenuTabLink\" href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL13 ShadowText\">".$idesc."</div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL14\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL15\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL16\"></div></a></div></td>\n";
					$idesc =~ s/\<br\>//gi;
					$pagetitle .= ": $idesc";
				} else {
					$mainmenu .= "<td><div id=\"div_maintab_".$meid."\" class=\"MainTab\" onmouseover=\"main_cap('div_maintab_".$meid."');\" onmouseout=\"main_uncap('div_maintab_".$meid."');\"><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL30\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL31\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL32\"></div></a><a class=\"MenuTabLink\" href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL33 ShadowText\">".$idesc."</div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL34\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL35\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"MainTabL36\"></div></a></div></td>\n";
				}
			} else {
				if ($isubm eq $uismode) {
					$submenu .= "<td nowrap=\"nowrap\"><div id=\"div_subtab_".$meid."\"><div class=\"SubTabL10\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL11\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL12\"></div></a><a class=\"MenuTabLink\" href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL13\">".$idesc."</div></a></div></td>\n";
					$idesc =~ s/\<br\>//gi;
					$pagetitle .= ": $idesc";
				} else {
					$submenu .= "<td nowrap=\"nowrap\"><div id=\"div_subtab_".$meid."\" class=\"SubTab\" onmouseover=\"sub_cap('div_subtab_".$meid."');\" onmouseout=\"sub_uncap('div_subtab_".$meid."');\"><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL30\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL31\"></div></a><a href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL32\"></div></a><a class=\"MenuTabLink\" href=\"./engine.pl?mode=$imenu&submode=$isubm\"><div class=\"SubTabL33\">".$idesc."</div></a></div></td>\n";
				}
			}
		}
	}
	$sth->finish;
}

# switch to usermode

if (($uimode eq "logout") && ($uismode eq "usermode") && ($uaccess >= $alevel{$uimode.$uismode})) {
	$cusermode = ($cusermode > 0)?0:1;
	my $fut_time = gmtime(time() + (60 * 60 * 24 * 30))." GMT";  	# cookie expires in 30 days
	my $cookie = "usermode2014=$cusermode; path=/; expires=$fut_time;";
	print "Set-Cookie: " . $cookie . "\n";
	($uimode, $uismode) = ("status", "relays");
}
my $usermode = ($uaccess > 0)?"<a href=\"./engine.pl?mode=logout&submode=usermode\" class=\"submenu\">Switch to ".(($cusermode == 0)?"usermode":"adminmode")."</a>":"&nbsp;".$ulogin;
if ($cusermode > 0) {
	$uaccess--;
}

# HVAC general menu

if (($uimode eq "hvac") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my ($subtitle, $items) = ("", "");
	my $all = $db->selectall_arrayref("SELECT id, submenu, option_, description, value_, type_, selections, permissions, units FROM hvac WHERE permissions <= $uaccess AND (option_ = '$uismode' OR option_ LIKE '".$uismode.".%') ORDER BY id");
	foreach my $row (@$all) {
		if (@$row[1] == 0) {			# main item
			$subtitle = @$row[3];
		} else {
			$items .= "<tr><td height=28 width=328>".@$row[3].":</td><td align=\"left\" width=316>";
			if (($action eq "save") && (exists $FORM{@$row[2]})) {
				if ($FORM{@$row[2]} ne @$row[4]) {
					@$row[4] = $FORM{@$row[2]};
					dbdo("UPDATE hvac SET value_='".$FORM{@$row[2]}."' WHERE option_='".@$row[2]."'", 0);
				}
			}
			if (@$row[5] == 1) {			# text field
				my $fsize = (@$row[6] eq "")?5:(@$row[6] + 0);
				$items .= "<input name=\"".@$row[2]."\" value=\"".@$row[4]."\" size=\"$fsize\" maxlength=\"".($fsize * 2)."\" type=\"text\"> ".@$row[8];
			} elsif (@$row[5] == 3) {		# drop down
				$items .= "<select name=\"".@$row[2]."\" size=1>";
				my @opts = split(/\;\;/,@$row[6]);
				for my $oopt (0 .. $#opts) {
					my ($ovalue, $odesc) = split(/\:\:/, $opts[$oopt]);
					$items .= "<option value=\"$ovalue\"".((@$row[4] eq $ovalue)?" selected=\"selected\"":"").">$odesc</option>";
				}
				$items .= "</select>";
			}
			$items .= "</td></tr>\n";
		}
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--subtitle--/$subtitle/g;
		$inline =~ s/--items--/$items/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# relays status page

if (($uimode eq "status") && ($uismode eq "relays") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $bypass = 0;
	my $all = $db->selectall_arrayref("SELECT status FROM bypass ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		($bypass) = @$row;
	}
	$sth->finish;
	undef $all;
	$bypass = ($bypass == 0)?"Disabled":"Enabled";

	my $hbypass = 0;
	my $all = $db->selectall_arrayref("SELECT status FROM bypass WHERE type_ = 0 ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		($hbypass) = @$row;
	}
	$sth->finish;
	undef $all;
	my $bypasshw = ($hbypass == 0)?"OFF":"ON";

	my ($relayupd, $wireupd) = ("N/A", "N/A");
	my ($relayw1, $relayw2, $relayr1, $relayy1, $relayr2, $relayy2, $relayr3, $relayg, $relayr4, $relayob, $relayr5, $relayhum, $relayr6) = ("N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
	my $all = $db->selectall_arrayref("SELECT r1, r2, r3, r4, r5, r6, humidifier, w1, w2, y1, y2, g, ob, updated FROM relays ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$relayr1 = (@$row[0] == 0)?"OFF":"ON";
		$relayr2 = (@$row[1] == 0)?"OFF":"ON";
		$relayr3 = (@$row[2] == 0)?"OFF":"ON";
		$relayr4 = (@$row[3] == 0)?"OFF":"ON";
		$relayr5 = (@$row[4] == 0)?"OFF":"ON";
		$relayr6 = (@$row[5] == 0)?"OFF":"ON";
		$relayhum = (@$row[6] == 0)?"OFF":"ON";
		$relayw1 = (@$row[7] == 0)?"OFF":"ON";
		$relayw2 = (@$row[8] == 0)?"OFF":"ON";
		$relayy1 = (@$row[9] == 0)?"OFF":"ON";
		$relayy2 = (@$row[10] == 0)?"OFF":"ON";
		$relayg = (@$row[11] == 0)?"OFF":"ON";
		$relayob = (@$row[12] == 0)?"OFF":"ON";
		$relayupd = @$row[13];
	}
	$sth->finish;
	undef $all;

	my ($wirew1, $wirew2, $wirey1, $wirey2, $wireg, $wireob, $avgmzt) = ("N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
	my $all = $db->selectall_arrayref("SELECT w1, w2, y1, y2, g, ob, updated, avg_t FROM thermostat ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$wirew1 = (@$row[0] == 0)?"OFF":"ON";
		$wirew2 = (@$row[1] == 0)?"OFF":"ON";
		$wirey1 = (@$row[2] == 0)?"OFF":"ON";
		$wirey2 = (@$row[3] == 0)?"OFF":"ON";
		$wireg = (@$row[4] == 0)?"OFF":"ON";
		$wireob = (@$row[5] == 0)?"OFF":"ON";
		$wireupd = @$row[6];
		$avgmzt = (@$row[7] eq "")?"N/A":(sprintf("%.1f",@$row[7])."&deg;C");
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);	
		$inline =~ s/--avg_t--/$avgmzt/g;
		$inline =~ s/--relay_w1--/$relayw1/g;
		$inline =~ s/--relay_w2--/$relayw2/g;
		$inline =~ s/--relay_r1--/$relayr1/g;
		$inline =~ s/--relay_y1--/$relayy1/g;
		$inline =~ s/--relay_r2--/$relayr2/g;
		$inline =~ s/--relay_y2--/$relayy2/g;
		$inline =~ s/--relay_r3--/$relayr3/g;
		$inline =~ s/--relay_g--/$relayg/g;
		$inline =~ s/--relay_r4--/$relayr4/g;
		$inline =~ s/--relay_ob--/$relayob/g;
		$inline =~ s/--relay_r5--/$relayr5/g;
		$inline =~ s/--relay_hum--/$relayhum/g;
		$inline =~ s/--relay_r6--/$relayr6/g;
		$inline =~ s/--wire_w1--/$wirew1/g;
		$inline =~ s/--wire_w2--/$wirew2/g;
		$inline =~ s/--wire_y1--/$wirey1/g;
		$inline =~ s/--wire_y2--/$wirey2/g;
		$inline =~ s/--wire_g--/$wireg/g;
		$inline =~ s/--wire_ob--/$wireob/g;
		$inline =~ s/--relayupd--/$relayupd/g;
		$inline =~ s/--wireupd--/$wireupd/g;
		$inline =~ s/--bypass--/$bypass/g;
		$inline =~ s/--bypasshw--/$bypasshw/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# onboard sensors status

if (($uimode eq "status") && ($uismode eq "onboard") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my ($froomt, $froomh, $ductco1, $ductco2, $sductt, $sducth, $rductt, $rducth, $htut, $airvel, $smartupd) = ("N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
	my $all = $db->selectall_arrayref("SELECT froom_t, froom_h, co, co2, t_supply_duct, t_return_duct, h_supply_duct, h_return_duct, htu, air_vel, updated FROM smartsensors ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$froomt = (@$row[0] ne "")?(@$row[0]."&deg;C"):"N/A";
		$froomh = (@$row[1] ne "")?(@$row[1]."%"):"N/A";
		$ductco1 = (@$row[2] ne "")?(@$row[2]."ppm"):"N/A";
		$ductco2 = (@$row[3] ne "")?(@$row[3]."ppm"):"N/A";
		$sductt = (@$row[4] ne "")?(@$row[4]."&deg;C"):"N/A";
		$rductt = (@$row[5] ne "")?(@$row[5]."&deg;C"):"N/A";
		$sducth = (@$row[6] ne "")?(@$row[6]."%"):"N/A";
		$rducth = (@$row[7] ne "")?(@$row[7]."%"):"N/A";
		$htut = (@$row[8] ne "")?(@$row[8]."&deg;C"):"N/A";
		$airvel = (@$row[9] ne "")?(@$row[9]."fpm"):"N/A";
		$smartupd = @$row[10];
	}
	$sth->finish;
	undef $all;
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--froom_t--/$froomt/g;
		$inline =~ s/--froom_h--/$froomh/g;
		$inline =~ s/--t_supply_duct--/$sductt/g;
		$inline =~ s/--h_supply_duct--/$sducth/g;
		$inline =~ s/--t_return_duct--/$rductt/g;
		$inline =~ s/--h_return_duct--/$rducth/g;
		$inline =~ s/--co--/$ductco1/g;
		$inline =~ s/--co2--/$ductco2/g;
		$inline =~ s/--htu--/$htut/g;
		$inline =~ s/--air_vel--/$airvel/g;
		$inline =~ s/--smart_upd--/$smartupd/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# indoor sensors status

if (($uimode eq "status") && ($uismode eq "indoor") && ($uaccess >= $alevel{$uimode.$uismode})) {

	my ($mastert, $masterh, $masterl) = ("N/A", "N/A", "N/A");
	# master sensors TBD

	my ($zonet, $zoneh, $zonel) = ("N/A", "N/A", "N/A");
	my $curzone = (exists $FORM{curzone})?($FORM{curzone} + 0):2;	# have to be first real zone
	my $all = $db->selectall_arrayref("SELECT AVG(paramsensordyn.temperature), AVG(paramsensordyn.humidity), AVG(paramsensordyn.light) FROM paramsensordyn, devices WHERE paramsensordyn.device_id = devices.id AND devices.zone_id = $curzone AND devices.device_type = 1");
	foreach my $row (@$all) {
		$zonet = (@$row[0] ne "")?(@$row[0]."&deg;C"):"N/A";
		$zoneh = (@$row[1] ne "")?(@$row[1]."%"):"N/A";
		$zonel = (@$row[2] ne "")?(@$row[2]." lux"):"N/A";
	}
	$sth->finish;
	undef $all;

	my ($zonesl, $zoneo) = ("", "N/A");
	my $all = $db->selectall_arrayref("SELECT zones.id, zonesdyn.occupation, zones.description FROM zones, zonesdyn WHERE zonesdyn.zone_id = zones.id AND zones.volume > 0 ORDER BY zones.id");
	foreach my $row (@$all) {
		$zonesl .= "<option value=\"".@$row[0]."\"".((@$row[0] == $curzone)?" selected=\"selected\"":"").">ID: ".@$row[0]." : ".@$row[2]."</option>";
		if (@$row[0] == $curzone) {
			$zoneo = (@$row[1] > 0)?((@$row[1] > 1)?"Semi-occupied":"Occupied"):"Not occupied";
		}
	}
	$sth->finish;
	undef $all;
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--curzone--/$curzone/g;
		$inline =~ s/--master_t--/$mastert/g;
		$inline =~ s/--master_h--/$masterh/g;
		$inline =~ s/--master_l--/$masterl/g;
		$inline =~ s/--zone_t--/$zonet/g;
		$inline =~ s/--zone_h--/$zoneh/g;
		$inline =~ s/--zone_l--/$zonel/g;
		$inline =~ s/--zone_o--/$zoneo/g;
		$inline =~ s/--zones--/$zonesl/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# outdoor sensors status

if (($uimode eq "status") && ($uismode eq "outdoor") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my ($outdoort, $outdoorh, $outdoorl, $outdoorcnt) = ("N/A", "N/A", "N/A", 0);
	my $all = $db->selectall_arrayref("SELECT AVG(paramsensordyn.temperature), AVG(paramsensordyn.humidity), AVG(paramsensordyn.light), COUNT(paramsensordyn.device_id) FROM paramsensordyn, devices WHERE paramsensordyn.device_id = devices.id AND devices.zone_id > 1 AND devices.device_type = 0");
	foreach my $row (@$all) {
		$outdoort = (@$row[0] ne "")?(@$row[0]."&deg;C"):"N/A";
		$outdoorh = (@$row[1] ne "")?(@$row[1]."%"):"N/A";
		$outdoorl = (@$row[2] ne "")?(@$row[2]." lux"):"N/A";
		$outdoorcnt = @$row[3];
	}
	$sth->finish;
	undef $all;

	my ($weathert, $weatherh, $weatherloc, $weatherw, $weatherap, $weatherc) = ("N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
	{
		my $all = $db->selectall_arrayref("SELECT updated, name, value FROM smartstatus WHERE group_ = 'weather'");
		foreach my $row (@$all) {
			if (@$row[1] eq "temp") {
				$weathert = (@$row[2] ne "")?(@$row[2]."&deg;C"):"N/A";
			} elsif (@$row[1] eq "humid") {
				$weatherh = (@$row[2] ne "")?(@$row[2]."%"):"N/A";
			} elsif (@$row[1] eq "location") {
				$weatherloc = (@$row[2] ne "")?(@$row[2]):"N/A";
			} elsif (@$row[1] eq "air_pres") {
				$weatherap = (@$row[2] ne "")?(@$row[2]):"N/A";
			} elsif (@$row[1] eq "cond") {
				$weatherc = (@$row[2] ne "")?(@$row[2]):"N/A";
			} elsif (@$row[1] eq "wind") {
				if (@$row[2] ne "") {
					my ($wsp, $wdir) = split(/\ /, @$row[2]);
					my $wtdir = "North";
					if (($wdir >= 11.25) && ($wdir <= 33.75)) {
						$wtdir = "North-North-East";
					} elsif (($wdir >= 33.75) && ($wdir <= 56.25)) {
						$wtdir = "North-East";
					} elsif (($wdir >= 56.25) && ($wdir <= 78.75)) {
						$wtdir = "East-North-East";
					} elsif (($wdir >= 78.75) && ($wdir <= 101.25)) {
						$wtdir = "East";
					} elsif (($wdir >= 101.25) && ($wdir <= 123.75)) {
						$wtdir = "East-South-East";
					} elsif (($wdir >= 123.75) && ($wdir <= 146.25)) {
						$wtdir = "South-East";
					} elsif (($wdir >= 146.25) && ($wdir <= 168.75)) {
						$wtdir = "South-South-East";
					} elsif (($wdir >= 168.75) && ($wdir <= 191.25)) {
						$wtdir = "South";
					} elsif (($wdir >= 191.25) && ($wdir <= 213.75)) {
						$wtdir = "South-South-West";
					} elsif (($wdir >= 213.75) && ($wdir <= 236.25)) {
						$wtdir = "South-West";
					} elsif (($wdir >= 236.25) && ($wdir <= 258.75)) {
						$wtdir = "West-South-West";
					} elsif (($wdir >= 258.75) && ($wdir <= 281.25)) {
						$wtdir = "West";
					} elsif (($wdir >= 281.25) && ($wdir <= 303.75)) {
						$wtdir = "West-North-West";
					} elsif (($wdir >= 303.75) && ($wdir <= 326.25)) {
						$wtdir = "North-West";
					} elsif (($wdir >= 326.25) && ($wdir <= 348.75)) {
						$wtdir = "North-North-West";
					}
					$weatherw = $wtdir.", ".$wsp." m/sec";
				}
			}
		}
		$sth->finish;
		undef $all;
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--outdoor_cnt--/$outdoorcnt/g;
		$inline =~ s/--outdoor_t--/$outdoort/g;
		$inline =~ s/--outdoor_h--/$outdoorh/g;
		$inline =~ s/--outdoor_l--/$outdoorl/g;
		$inline =~ s/--wfc_t--/$weathert/g;
		$inline =~ s/--wfc_h--/$weatherh/g;
		$inline =~ s/--wfc_loc--/$weatherloc/g;
		$inline =~ s/--wfc_w--/$weatherw/g;
		$inline =~ s/--wfc_ap--/$weatherap/g;
		$inline =~ s/--wfc_cond--/$weatherc/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# system status

if (($uimode eq "status") && ($uismode eq "system") && ($uaccess >= $alevel{$uimode.$uismode})) {
        my ($caset) = ("N/A");
	my $all = $db->selectall_arrayref("SELECT t_int FROM smartsensors ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$caset = (@$row[0] ne "")?(@$row[0]."&deg;C"):"N/A";
	}
	$sth->finish;
	undef $all;

	my $sernum = (exists $HVAC{"system.serial"})?$HVAC{"system.serial"}:"N/A";
	my $houseid = (exists $HVAC{"system.house_id"})?(sprintf("%05d",$HVAC{"system.house_id"})):"N/A";

	my ($syscpu, $sysram, $sysdisk, $sysup) = ("N/A", "N/A", "N/A", "N/A");
	my $all = $db->selectall_arrayref("SELECT updated, name, value FROM smartstatus WHERE group_ = 'health'");
	foreach my $row (@$all) {
		if (@$row[1] eq "cpu") {
			$syscpu = @$row[2];
		} elsif (@$row[1] eq "ram") {
			$sysram = @$row[2];
		} elsif (@$row[1] eq "disk") {
			$sysdisk = @$row[2];
		} elsif (@$row[1] eq "uptime") {
			$sysup = @$row[2];
		}
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--serial--/$sernum/g;
		$inline =~ s/--house_id--/$houseid/g;
		$inline =~ s/--sys_cpu--/$syscpu/g;
		$inline =~ s/--sys_ram--/$sysram/g;
		$inline =~ s/--sys_disk--/$sysdisk/g;
		$inline =~ s/--sys_up--/$sysup/g;
#		$inline =~ s/--bypasshw--/$bypasshw/g;
		$inline =~ s/--case_t--/$caset/g;
#		$inline =~ s/--t_supply_duct--/$tsduct/g;
#		$inline =~ s/--t_return_duct--/$trduct/g;
#		$inline =~ s/--h_supply_duct--/$hsduct/g;
#		$inline =~ s/--h_return_duct--/$hrduct/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# networks status

if (($uimode eq "status") && ($uismode eq "networks") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my ($netip, $netgw, $netwan, $netcloud, $wanlist, $wancip, $wancgw, $dnslst) = ("N/A", "N/A", "N/A", "N/A", "", "N/A", "N/A", "N/A");
	{
		my $all = $db->selectall_arrayref("SELECT updated, name, value FROM smartstatus WHERE group_ = 'network'");
		foreach my $row (@$all) {
			if (@$row[1] eq "ip_main") {
				$netip = @$row[2];
			} elsif (@$row[1] eq "gateway") {
				$netgw = @$row[2];
			} elsif (@$row[1] eq "ip_wan") {
				$netwan = @$row[2];
			} elsif (@$row[1] eq "cloud") {
				$netcloud = @$row[2];
			} elsif (@$row[1] eq "ip_cwan") {
				$wancip = (@$row[2] ne "")?@$row[2]:"N/A";
			} elsif (@$row[1] eq "gw_cwan") {
				$wancgw = (@$row[2] ne "")?@$row[2]:"N/A";
			} elsif (@$row[1] eq "dns") {
				unless (@$row[2] eq "") {
					$dnslst = "";
					my @dlst = split(/\;/, @$row[2]);
					foreach my $ditem (@dlst) {
						$dnslst .= $ditem."<br>";
					}
				}
			} elsif (@$row[1] eq "list_wan") {
				unless (@$row[2] eq "") {
					$wanlist = "<tr><td colspan=2><div class=\"in10\"></div></td></tr>";
					my ($wwwip, $wwwmac) = ("", "");
					my @wlst = split(/\;/, @$row[2]);
					foreach my $witem (@wlst) {
						my ($wwip, $wwmac) = split(/\,/, $witem);
						$wwwip .= $wwip."<br>";
						$wwwmac .= "MAC: ".$wwmac."<br>";
					}
					$wanlist .= "<tr><td nowrap=\"nowrap\" width=\"165\" valign=top>Clients Connected:</td><td class=\"stdbold\" nowrap=\"nowrap\" width=100>$wwwip</td><td class=\"stdbold\" nowrap=\"nowrap\">$wwwmac</td></tr>\n";
				}
			}
		}
		$sth->finish;
		undef $all;
	}

	my ($wanap, $wancap) = ("N/A", "N/A");
	{
		my $all = $db->selectall_arrayref("SELECT ap_name, wan_ap_name FROM networks ORDER BY id DESC limit 1");
		foreach my $row (@$all) {
			unless (@$row[0] eq "") {
				$wanap = @$row[0];
			}
			unless (@$row[1] eq "") {
				$wancap = @$row[1];
			}
		}
		$sth->finish;
		undef $all;
	}
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--wan_list--/$wanlist/g;
		$inline =~ s/--dns--/$dnslst/g;
		$inline =~ s/--net_ip--/$netip/g;
		$inline =~ s/--net_gw--/$netgw/g;
		$inline =~ s/--net_wan--/$netwan/g;
		$inline =~ s/--net_cloud--/$netcloud/g;
		$inline =~ s/--wanc_ap--/$wancap/g;
		$inline =~ s/--wanc_ip--/$wancip/g;
		$inline =~ s/--wanc_gw--/$wancgw/g;
		$inline =~ s/--wan_ap--/$wanap/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# zigbee network status

if (($uimode eq "status") && ($uismode eq "zigbee") && ($uaccess >= $alevel{$uimode.$uismode})) {
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# Zones management

if (($uimode eq "zonedev") && ($uismode eq "zones") && ($uaccess >= $alevel{$uimode.$uismode})) {
	if ($action eq "remove") {
		my $zoneid = $FORM{zoneid} + 0;
		if ($zoneid > 2) {			# if someones try to delete master zone
			dbdo("UPDATE devices SET zone_id = 1 WHERE zone_id = $zoneid", 0);		# move orphaned devices to zone1
			dbdo("DELETE FROM zonesdyn WHERE zone_id = $zoneid", 0);
			dbdo("DELETE FROM zonesadvanced WHERE zone_id = $zoneid", 0);
			dbdo("DELETE FROM states WHERE zone_id = $zoneid", 0);
			dbdo("DELETE FROM zones WHERE id = $zoneid", 0);
		}
	}

	if (($action eq "save") && ($FORM{zonesn} ne "")) {
		dbdo("INSERT INTO zones VALUES (0, 1, '".$FORM{zonesn}."', 1)", 0);
		my $sth = $db->prepare("SELECT last_insert_id() FROM zones");
		$sth->execute;
		my ($nzoneid) = $sth->fetchrow_array();
		$sth->finish;
		undef $sth;
		dbdo("INSERT INTO zonesdyn VALUES ($nzoneid, 0, 0, 0, 0, 0)", 0);
	}

	my @zones = ("");
	my $zonesl = "";
	my $all = $db->selectall_arrayref("SELECT id, description FROM zones ORDER BY id");
	foreach my $row (@$all) {
		my $zonedef = "zones".@$row[0];
		if (($action eq "save") && ($FORM{$zonedef} ne ""))  {
			if ($FORM{$zonedef} ne @$row[1]) {
				dbdo("UPDATE zones SET description = '".$FORM{$zonedef}."' WHERE id = ".@$row[0], 0);
				@$row[1] = $FORM{$zonedef};
			}
		}
		if (@$row[0] == 1) {
			$zones[1] = @$row[1];
		} elsif (@$row[0] == 2) {
			$zones[2] = @$row[1];
		} else {
			$zonesl .= "<tr><td nowrap=\"nowrap\" width=\"138\">Zone ID #".@$row[0].":</td><td><input name=\"zones".@$row[0]."\" size=\"25\" maxlength=\"50\" value=\"".@$row[1]."\" type=\"text\">&nbsp;&nbsp;&nbsp;<input name=\"zones".@$row[0]."del\" value=\"Delete Zone\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&zoneid=".@$row[0]."&action=remove'\" type=\"button\"></td></tr>\n";
		}
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--zones1--/$zones[1]/g;
		$inline =~ s/--zones2--/$zones[2]/g;
		$inline =~ s/--zonesl--/$zonesl/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# Devices management

if (($uimode eq "zonedev") && ($uismode eq "devices") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my %asemp = ();
	{
		my $all = $db->selectall_arrayref("SELECT profile_id, description FROM asemp WHERE type_ = 2 ORDER BY profile_id");
		foreach my $row (@$all) {
#			$asemp{@$row[0]} = @$row[1];
			$asemp{@$row[0]} = (@$row[0] == 0)?"Default":"User #".@$row[0];
		}
		$sth->finish;
		undef $all;
	}

	my %zones = ();
	{
		my $all = $db->selectall_arrayref("SELECT id, description FROM zones ORDER BY id");
		foreach my $row (@$all) {
			$zones{@$row[0]} = @$row[1];
		}
		$sth->finish;
		undef $all;
	}

	my @devtypes = ("Sensor", "Sensor", "Louver", "Louver", "Controller", "Controller");
	my $devices = "";
	my $dlmzone = 0;
	{
		my $all = $db->selectall_arrayref("SELECT devices.id, devices.zone_id, devices.device_type, devices.description, devices.asemp, devicesdyn.online FROM devices LEFT JOIN devicesdyn ON devicesdyn.device_id = devices.id ORDER BY devices.zone_id, devices.id");
		foreach my $row (@$all) {
			my ($devid, $dzoneid, $dtype, $ddesc, $dasemp, $dstat) = @$row;
			$dstat += 0;
			my $upbord = "";
			if (($dlmzone > 0) && ($dlmzone != $dzoneid)) {
				$upbord = "<div class=in10></div>";
				$dlmzone = $dzoneid;
			} elsif ($dlmzone == 0) {
				$dlmzone = $dzoneid;
			}
			if ($action eq "save") {
				if ((exists $FORM{"dz".$devid}) && ($FORM{"dz".$devid} != $dzoneid)) {
					$dzoneid = $FORM{"dz".$devid};
					dbdo("UPDATE devices SET zone_id = '$dzoneid' WHERE id = $devid", 0);
				}
				if ((exists $FORM{"dd".$devid}) && ($FORM{"dd".$devid} ne $ddesc)) {
					$ddesc = $FORM{"dd".$devid};
					dbdo("UPDATE devices SET description = '$ddesc' WHERE id = $devid", 0);
				}
				if ((exists $FORM{"da".$devid}) && ($FORM{"da".$devid} != $dasemp)) {
					$dasemp = $FORM{"da".$devid};
					dbdo("UPDATE devices SET asemp = '$dasemp' WHERE id = $devid", 0);
				}
				if ((exists $FORM{"ds".$devid}) && ($FORM{"ds".$devid} != $dstat)) {
					$dstat = $FORM{"ds".$devid};
					dbdo("REPLACE INTO devicesdyn (device_id, online) VALUES ($devid, '$dstat')", 0);
				}
			}
			$devices .= "<tr><td nowrap=\"nowrap\" width=40>$upbord".$devtypes[$dtype]."&nbsp;</td>\n
				<td nowrap=\"nowrap\" width=100>$upbord<input name=\"dd".$devid."\" size=20 maxlength=50 value=\"$ddesc\" type=text></td>\n
				<td nowrap=\"nowrap\" width=100>$upbord<select name=\"dz".$devid."\" size=1>";
			foreach my $izone (sort keys %zones) {
				$devices .= "<option value=\"$izone\"".(($izone == $dzoneid)?" selected":"").">".$zones{$izone}."</option>";
			}
			$devices .= "</select></td>
				<td nowrap=\"nowrap\" width=50>$upbord<select name=\"da".$devid."\" size=1>";
			foreach my $iasemp (sort keys %asemp) {
				$devices .= "<option value=\"$iasemp\"".(($iasemp == $dasemp)?" selected":"").">".$asemp{$iasemp}."</option>";
			}
			$devices .= "</select></td>
				<td nowrap=\"nowrap\" width=50>$upbord<select name=\"ds".$devid."\" size=1>
				<option value=\"1\"".(($dstat > 0)?" selected":"").">Enabled</option>
				<option value=\"0\"".(($dstat > 0)?"":" selected").">Disabled</option>
				</select></td></tr>\n";
		}
		$sth->finish;
		undef $all;
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--devices--/$devices/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# Devices management

if (($uimode eq "zonedev") && ($uismode eq "newdev") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my %zones = ();
	my $lzones = "";
	{
		my $all = $db->selectall_arrayref("SELECT id, description FROM zones ORDER BY id");
		foreach my $row (@$all) {
			$zones{@$row[0]} = @$row[1];
			$lzones .= "<option value=\"".@$row[0]."\">".@$row[1]."</option>";
		}
		$sth->finish;
		undef $all;
	}

	my @regmode = ("", "", "");
	if (($action eq "save") && (exists $FORM{regmode})) {
		my $newregmode = $FORM{regmode} + 0;
		if ($HVAC{"system.regmode"} != $newregmode) {
			$HVAC{"system.regmode"} = $newregmode;
			dbdo("UPDATE hvac SET value_ = $newregmode WHERE option_ = 'system.regmode';", 0);
		}
	}
	$regmode[$HVAC{"system.regmode"}] = " selected";

	my ($recent, $pending) = ("", "");
	my @devtypes = ("ASE Outdoor Sensor", "ASE Indoor Sensor", "Louver Complete", "Louver Insert", "ASE Bathroom Fan Controller", "ASE Booster Fan Controller");
	{
		my $allrows = 0;
		my $all = $db->selectall_arrayref("SELECT id, device_type, zigbee_addr64, zigbee_mode, zone_id, status, serial FROM registrations WHERE status = 0 AND event_type = 1 ORDER BY id");	# only pending
		foreach my $row (@$all) {
			my ($devid, $dtype, $addr64, $dmode, $zoneid, $dstat, $sernum) = @$row;
			if (($action eq "accept") && ($FORM{devid} == $devid) && ($HVAC{"system.regmode"} > 0)) {
				my $newzone = 1;								# default zone
				if ($HVAC{"system.regmode"} == 2) {
					$newzone = $FORM{"newzone"} + 0;
				}
				dbdo("UPDATE registrations SET status = 2, zone_id = '$newzone' WHERE id = $devid", 0);
				dbdo("INSERT INTO devices VALUES(NULL, '$newzone', 0, '$dtype', '".$devtypes[$dtype]."', '$addr64', 1, '$sernum')", 0);
			} elsif (($action eq "reject") && ($FORM{devid} == $devid) && ($HVAC{"system.regmode"} > 0)) {
				dbdo("UPDATE registrations SET status = 3 WHERE id = $devid", 0);
			} else {
				$allrows++;
				$pending .= "<tr>
						<td nowrap=\"nowrap\" width=\"138\" class=\"stdbold\">".$devtypes[$dtype]."</td>";
				if (($HVAC{"system.regmode"} == 1) || ($HVAC{"system.regmode"} == 0)) {
					$pending .= "<td nowrap=\"nowrap\" width=\"138\" >MAC: ".$addr64."</td>";
				} elsif ($HVAC{"system.regmode"} == 2) {
					$pending .= "<td nowrap=\"nowrap\" width=\"138\" ><select name=\"newreg".$devid."z\" id=\"newreg".$devid."z\" size=\"1\">$lzones</select></td>";
				}
				$pending .= "<td nowrap=\"nowrap\" width=\"138\" >&nbsp;";
				if ($HVAC{"system.regmode"} == 2) {
					$pending .= "<input name=\"newreg".$devid."ok\" value=\"Accept\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&action=accept&devid=$devid&newzone='+document.newdev.newreg".$devid."z.value;\" type=\"button\">&nbsp;<input name=\"newreg".$devid."del\" value=\"Reject\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&action=reject&devid=$devid'\" type=\"button\">";
				} elsif ($HVAC{"system.regmode"} == 1) {
					$pending .= "<input name=\"newreg".$devid."ok\" value=\"Accept\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&action=accept&devid=$devid'\" type=\"button\">&nbsp;<input name=\"newreg".$devid."del\" value=\"Reject\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&action=reject&devid=$devid'\" type=\"button\">";
				}
				$pending .= "</td></tr>\n";
			}
		}
		$sth->finish;
		undef $all;
		if ($allrows == 0) {
			$pending .= "<td nowrap=\"nowrap\" class=\"stdbold\">No remote devices registrations pending</td>";
		}

		my $donerows = 0;
		my $all = $db->selectall_arrayref("SELECT id, device_type, zigbee_addr64, zigbee_mode, zone_id, status FROM registrations WHERE status BETWEEN 2 AND 3 AND event_type = 1 ORDER BY id DESC LIMIT 10");	# only recent
		foreach my $row (@$all) {
			my ($devid, $dtype, $addr64, $dmode, $zoneid, $dstat) = @$row;
			$donerows++;
			$recent .= "<tr>
					<td nowrap=\"nowrap\" width=\"138\" class=\"stdbold\">".$devtypes[$dtype]."</td>
					<td nowrap=\"nowrap\" width=\"118\" >".$addr64."</td>
					<td nowrap=\"nowrap\" width=\"138\" >".(($dstat == 2)?"#".$zoneid.": ".$zones{$zoneid}:"&nbsp;")."</td>
					<td nowrap=\"nowrap\" >&nbsp;".(($dstat == 2)?"Accepted":"Rejected")."</td>
				</tr>\n";
		}
		$sth->finish;
		undef $all;
		if ($donerows == 0) {
			$recent .= "<td nowrap=\"nowrap\" class=\"stdbold\">No recent remote device registrations to show</td>";
		} else {
			$recent = "<tr><td nowrap=\"nowrap\" width=\"138\">&nbsp;</td><td nowrap=\"nowrap\" width=\"118\" class=\"stdbold\">MAC Address</td><td nowrap=\"nowrap\" width=\"138\" class=\"stdbold\">Assigned Zone</td><td nowrap=\"nowrap\" class=\"stdbold\">&nbsp;Registration</td></tr>\n".$recent;
		}
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--regmode0--/$regmode[0]/g;
		$inline =~ s/--regmode1--/$regmode[1]/g;
		$inline =~ s/--regmode2--/$regmode[2]/g;
		$inline =~ s/--recent--/$recent/g;
		$inline =~ s/--pending--/$pending/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# networks IP menu

if (($uimode eq "networks") && ($uismode eq "ip") && ($uaccess >= $alevel{$uimode.$uismode})) {
	if (($action eq "save") && (exists $FORM{netip_id})) {
		my $netipid = $FORM{netip_id};
		my $dhcp = $FORM{lan_dhcp} + 0;
		if ($dhcp == 0) {
			dbdo("UPDATE networks SET lan_netmask='".($FORM{lan_netmask0} + 0).".".($FORM{lan_netmask1} + 0).".".($FORM{lan_netmask2} + 0).".".($FORM{lan_netmask3} + 0)."', lan_gateway='".($FORM{lan_gateway0} + 0).".".($FORM{lan_gateway1} + 0).".".($FORM{lan_gateway2} + 0).".".($FORM{lan_gateway3} + 0)."', lan_ip='".($FORM{lan_ip0} + 0).".".($FORM{lan_ip1} + 0).".".($FORM{lan_ip2} + 0).".".($FORM{lan_ip3} + 0)."', dns1='".($FORM{dns10} + 0).".".($FORM{dns11} + 0).".".($FORM{dns12} + 0).".".($FORM{dns13} + 0)."', dns2='".($FORM{dns20} + 0).".".($FORM{dns21} + 0).".".($FORM{dns22} + 0).".".($FORM{dns23} + 0)."' WHERE id = $netipid", 0);
		}
		dbdo("UPDATE networks SET timeserver1 = '".$FORM{timeserver1}."', timeserver2 = '".$FORM{timeserver2}."', ap_security = '".$FORM{ap_security}."', ap_protocol = '".($FORM{ap_protocol} + 0)."', ap_channel = '".($FORM{ap_channel} + 0)."', ap_name = '".$FORM{ap_name}."', wan_ap_name = '".$FORM{wan_ap_name}."', wan_ap_key = '".$FORM{wan_ap_key}."' WHERE id = $netipid", 0);
	}

	my $netipid = 0;
        my @dns1 = (0, 0, 0, 0);
        my @dns2 = (0, 0, 0, 0);
        my @lanip = (0, 0, 0, 0);
        my @langw = (0, 0, 0, 0);
        my @lanmask = (0, 0, 0, 0);
        my ($timesrv1, $timesrv2) = ("", "");
        my ($cellmodem, $celltype) = ("N/A", "N/A");
        my ($apchannel, $approtocol) = (0, 0);
        my ($apsecurity, $apname) = ("", "");
        my ($wanapname, $wanapkey) = ("", "");
        my ($cloud1, $cloud2) = ("", "");
        my $dhcp = 0;
        my @ldhcp = ("", "");
	my $all = $db->selectall_arrayref("SELECT timeserver1, timeserver2, cell_modem, cell_type, ap_name, ap_channel, ap_security, ap_protocol, wan_ap_name, wan_ap_key, cloud1, cloud2, dns1, dns2, lan_ip, lan_gateway, lan_netmask, lan_dhcp, id FROM networks ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		($timesrv1, $timesrv2) = (@$row[0], @$row[1]);
		$cellmodem = (@$row[2] == 0)?"NO":"YES";
		$celltype = (@$row[3] ne "")?@$row[3]:"N/A";
		$apname = @$row[4];
		$apchannel = @$row[5] + 0;
		$apsecurity = @$row[6];
		$approtocol = @$row[7] + 0;
		($wanapname, $wanapkey) = (@$row[8], @$row[9]);
		($cloud1, $cloud2) = (@$row[10], @$row[11]);			# cloud scan is TBD
		@dns1 = split(/\./,@$row[12]);
		@dns2 = split(/\./,@$row[13]);
		@lanip = split(/\./,@$row[14]);
		@langw = split(/\./,@$row[15]);
		@lanmask = split(/\./,@$row[16]);
		$dhcp = @$row[17] + 0;
		if ($dhcp == 1) {				# dynamic? set params as r/o
			for my $iddx (0 .. 3) {
				$dns1[$iddx] .= "\" disabled=\"disabled";
				$dns2[$iddx] .= "\" disabled=\"disabled";
				$lanip[$iddx] .= "\" disabled=\"disabled";
				$langw[$iddx] .= "\" disabled=\"disabled";
				$lanmask[$iddx] .= "\" disabled=\"disabled";
			}
			$ldhcp[1] = "checked=\"checked\"";
		} else {
			$ldhcp[0] = "checked=\"checked\"";
		}
		$netipid = @$row[18];
	}
	$sth->finish;
	undef $all;

	my @wanapnames = ("LEPROSORIUM", "POLICE1", "CANNONDALE");		# list of available AP is TBD
	my $wanapnamel = "";
	for my $wapidx (0 .. $#wanapnames) {
		$wanapnamel .= "<option value=\"".$wanapnames[$wapidx]."\" ".(($wanapnames[$wapidx] eq $wanapname)?" selected=\"selected\"":"").">".$wanapnames[$wapidx]."</option>";
	}

	my @approtocols = ("WPA2", "WPA", "None");
	my $approtocoll = "";
	for my $appridx (0 .. $#approtocols) {
		$approtocoll .= "<option value=\"$appridx\" ".(($appridx == $approtocol)?" selected=\"selected\"":"").">".$approtocols[$appridx]."</option>";
	}

	my $apchannell = "";
	for my $apchan (0 .. 14) {
		$apchannell .= "<option value=\"$apchan\" ".(($apchan == $apchannel)?" selected=\"selected\"":"").">".(($apchan == 0)?"Auto":$apchan)."</option>";
	}

	my %timeservers = ("165.193.126.229", "nist1-nj2.ustiming.org (Weehawken, NJ)", "216.171.112.36", "nist1-ny2.ustiming.org (New York City, NY)", "206.246.122.250", "nist1-pa.ustiming.org (Hatfield, PA)", "129.6.15.30", "time-c.nist.gov (NIST, Gaithersburg, Maryland)", "98.175.203.200", "nist1-macon.macon.ga.us (Macon, Georgia)", "207.223.123.18", "wolfnisttime.com (Birmingham, Alabama)", "216.171.120.36", "nist1-chi.ustiming.org (Chicago, Illinois)", "96.226.242.9", "nist.time.nosc.us (Carrollton, Texas)", "50.245.103.198", "nist.expertsmi.com (Monroe, Michigan)", "64.113.32.5", "nist.netservicesgroup.com (Southfield, Michigan)", "66.219.116.140", "nisttime.carsoncity.k12.mi.us (Carson City, Michigan)", "216.229.0.179", "nist1-lnk.binary.net (Lincoln, Nebraska)", "24.56.178.140", "wwv.nist.gov (WWV, Fort Collins, Colorado)", "132.163.4.102", "time-b.timefreq.bldrdoc.gov (NIST, Boulder, Colorado)", "128.138.140.44", "utcnist.colorado.edu (University of Colorado, Boulder)", "128.138.141.172", "utcnist2.colorado.edu (University of Colorado, Boulder)", "198.60.73.8", "ntp-nist.ldsbc.edu (LDSBC, Salt Lake City, Utah)", "64.250.229.100", "nist1-lv.ustiming.org (Las Vegas, Nevada)", "216.228.192.69", "nist-time-server.eoni.com (La Grande, Oregon)", "69.25.96.13", "nist1.symmetricom.com (San Jose, California)");
	my $timesrv1l = "";
	my $timesrv2l = "";
	foreach my $timesrvip (sort keys %timeservers) {
		$timesrv1l .= "<option value=\"$timesrvip\"".(($timesrvip eq $timesrv1)?" selected=\"selected\"":"").">".$timeservers{$timesrvip}."</option>";
		$timesrv2l .= "<option value=\"$timesrvip\"".(($timesrvip eq $timesrv2)?" selected=\"selected\"":"").">".$timeservers{$timesrvip}."</option>";
	}
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--lan_dhcp1--/$ldhcp[1]/g;
		$inline =~ s/--lan_dhcp0--/$ldhcp[0]/g;
		$inline =~ s/--dns10--/$dns1[0]/g;
		$inline =~ s/--dns11--/$dns1[1]/g;
		$inline =~ s/--dns12--/$dns1[2]/g;
		$inline =~ s/--dns13--/$dns1[3]/g;
		$inline =~ s/--dns20--/$dns2[0]/g;
		$inline =~ s/--dns21--/$dns2[1]/g;
		$inline =~ s/--dns22--/$dns2[2]/g;
		$inline =~ s/--dns23--/$dns2[3]/g;
		$inline =~ s/--lan_netmask0--/$lanmask[0]/g;
		$inline =~ s/--lan_netmask1--/$lanmask[1]/g;
		$inline =~ s/--lan_netmask2--/$lanmask[2]/g;
		$inline =~ s/--lan_netmask3--/$lanmask[3]/g;
		$inline =~ s/--lan_ip0--/$lanip[0]/g;
		$inline =~ s/--lan_ip1--/$lanip[1]/g;
		$inline =~ s/--lan_ip2--/$lanip[2]/g;
		$inline =~ s/--lan_ip3--/$lanip[3]/g;
		$inline =~ s/--lan_gateway0--/$langw[0]/g;
		$inline =~ s/--lan_gateway1--/$langw[1]/g;
		$inline =~ s/--lan_gateway2--/$langw[2]/g;
		$inline =~ s/--lan_gateway3--/$langw[3]/g;
		$inline =~ s/--wan_ap_name--/$wanapnamel/g;
		$inline =~ s/--wan_ap_key--/$wanapkey/g;
		$inline =~ s/--ap_name--/$apname/g;
		$inline =~ s/--ap_channel--/$apchannell/g;
		$inline =~ s/--ap_protocol--/$approtocoll/g;
		$inline =~ s/--ap_security--/$apsecurity/g;
		$inline =~ s/--cell_modem--/$cellmodem/g;
		$inline =~ s/--cell_type--/$celltype/g;
		$inline =~ s/--timeserver1--/$timesrv1l/g;
		$inline =~ s/--timeserver2--/$timesrv2l/g;
		$inline =~ s/--cloud1--/$cloud1/g;
		$inline =~ s/--cloud2--/$cloud2/g;
		$inline =~ s/--netip_id--/$netipid/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# networks Zigbee menu

if (($uimode eq "networks") && ($uismode eq "zigbee") && ($uaccess >= $alevel{$uimode.$uismode})) {
	if (($action eq "save") && (exists $FORM{netzb_id})) {
		my $netzbid = $FORM{netzb_id};
		my $panidsel = $FORM{panid_sel} + 0;
		if ($panidsel == 0) {
			dbdo("UPDATE zigbee SET panid='".$FORM{panid}."' WHERE id = $netzbid", 0);
		}
		dbdo("UPDATE zigbee SET panid_sel=".$panidsel.", encryption=".($FORM{encryption} + 0).", channel=".($FORM{channel} + 0)." WHERE id = $netzbid", 0);
		if (exists $FORM{sec_key}) {
			dbdo("UPDATE zigbee SET sec_key='".$FORM{sec_key}."' WHERE id = $netzbid", 0);
		}
	}

	my ($zchannell, $zchannel, $zchansel) = ("", 0, 0);
	my @lzpanidsel = ("", "");
	my ($zpanidsel, $zpanid, $zpanidro, $zencryption) = (0, "", "", 0);
	my @lzencryption = ("", "");
        my ($zaddr64, $zaddr16, $zseckey, $zmfcid, $zhwversion, $zswversion) = ("N/A", "N/A", "N/A", "N/A", "N/A", "N/A");
        my $znetzbid = 0;
	my $all = $db->selectall_arrayref("SELECT addr64, addr16, sec_key, mfc_id, hw_version, sw_version, channel, panid_sel, panid, encryption, id FROM zigbee ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$zaddr64 = (@$row[0] ne "")?(uc(@$row[0])):"N/A";
		$zaddr16 = (@$row[1] ne "")?(uc(@$row[1])):"N/A";
		$zseckey = (@$row[2] ne "")?(@$row[2]):"";
		$zmfcid = (@$row[3] ne "")?(uc(@$row[3])):"N/A";
		$zhwversion = (@$row[4] ne "")?(@$row[4]):"N/A";
		$zswversion = (@$row[5] ne "")?(@$row[5]):"N/A";
		$zchannel = @$row[6] + 0;
		$zpanidsel = @$row[7] + 0;
		$zpanid = @$row[8];
		$zencryption = @$row[9] + 0;
		$znetzbid = @$row[10] + 0;
	}
	$sth->finish;
	undef $all;

	for my $zchan (0 .. 10) {
		$zchannell .= "<option value=\"$zchan\" ".(($zchan == $zchannel)?" selected=\"selected\"":"").">".(($zchan == 0)?"Auto":$zchan)."</option>";
	}
	$lzpanidsel[$zpanidsel] = "checked=\"checked\"";
	$lzencryption[$zencryption] = "checked=\"checked\"";
	$zpanidro = ($zpanidsel == 1)?" disabled=\"disabled\"":"";
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--panid_sel1--/$lzpanidsel[1]/g;
		$inline =~ s/--panid_sel0--/$lzpanidsel[0]/g;
		$inline =~ s/--encryption1--/$lzencryption[1]/g;
		$inline =~ s/--encryption0--/$lzencryption[0]/g;
		$inline =~ s/--panidro--/$zpanidro/g;
		$inline =~ s/--panid--/$zpanid/g;
		$inline =~ s/--channel--/$zchannell/g;
		$inline =~ s/--addr64--/$zaddr64/g;
		$inline =~ s/--addr16--/$zaddr16/g;
		$inline =~ s/--sec_key--/$zseckey/g;
		$inline =~ s/--mfc_id--/$zmfcid/g;
		$inline =~ s/--hw_version--/$zhwversion/g;
		$inline =~ s/--sw_version--/$zswversion/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--netzb_id--/$znetzbid/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# networks ASEMP profiles

if (($uimode eq "networks") && ($uismode eq "asemp") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $profid = $FORM{profile_id} + 0;
	my $aseprefix = "ASP";

	if (($action eq "remove") && ($profid > 0)) {
		dbdo("DELETE FROM asemp WHERE profile_id = $profid", 0);
		$profid = 0;
	}

	if (($action eq "save") && ($profid > 0)) {
		$db->{'AutoCommit'} = 0;
		foreach my $formkey (sort keys %FORM) {
			if ($formkey =~ m/^ASP(.*)/) {
				my $pname = $1;
				my $vname = $FORM{$formkey};
				dbdo("DELETE FROM asemp WHERE profile_id = $profid AND parameter = '$pname'", 0);
				dbdo("INSERT INTO asemp VALUES (NULL, $profid, '$pname', '$vname', '$vname', '$pname', 0, '')", 0);
			}
		}
		dbdo("DELETE FROM asemp WHERE profile_id = $profid AND parameter = 'name'", 0);
		dbdo("INSERT INTO asemp VALUES (NULL, $profid, 'name', '0', '0', 'User Defined ASEMP Profile $profid', 2, '')", 0);
		$db->commit();
		$db->{'AutoCommit'} = 1;
	}

	my $profile = "";
	my $proflist = "";
	my $profdel = "";
	my $pridmax = 0;
	my %pvalues = ();
	my $all = $db->selectall_arrayref("SELECT profile_id, parameter, value, default_, type_, units, description FROM asemp WHERE profile_id = $profid OR profile_id = 0 OR type_ = 2 ORDER BY profile_id DESC, id");
	foreach my $row (@$all) {
		my ($prid, $param, $value, $vdef, $vtype, $units, $desc) = @$row;
		if ($prid == $profid) {
			$pvalues{$param} = $value;			# store user defined profile values
		}
		if (($prid == 0) && ($vtype < 2)) {
			$profile .= "<tr><td width=250>".$desc.":</td><td align=left>";
			$value = (exists $pvalues{$param})?$pvalues{$param}:$value;
			if ($vtype == 0) {
				$profile .= "<input id=\"$aseprefix$param\" name=\"$aseprefix$param\" value=\"1\" ".(($value == 1)?"checked=\"checked\"":"")." type=\"radio\" ".(($profid == 0)?"disabled":"")."><b>Yes</b><input id=\"$aseprefix$param\" name=\"$aseprefix$param\" value=\"0\" ".(($value == 0)?"checked=\"checked\"":"")." type=\"radio\" ".(($profid == 0)?"disabled":"")."><b>No</b>";
			} elsif ($vtype == 1) {
				$profile .= "<input name=\"$aseprefix$param\" size=\"3\" maxlength=\"10\" value=\"".(($value eq "")?$vdef:$value)."\" type=\"text\" ".(($profid == 0)?"disabled":"")."> $units";
			}
			$profile .= "</td></tr>\n";
		}
		if ($vtype == 2) {
			$proflist .= "<option value=\"$prid\" ".(($profid == $prid)?"selected=\"selected\"":"").">$desc</option>";
		}
		$pridmax = ($pridmax > $prid)?$pridmax:$prid;
	}
	$sth->finish;
	$pridmax++;
	$proflist .= "<option value=\"$pridmax\" ".(($profid == $pridmax)?"selected=\"selected\"":"").">New ASEMP Profile</option>";
	if (($profid > 0) && ($profid < $pridmax)) {
		$profdel = "&nbsp;&nbsp;&nbsp;<input name=\"profdel\" value=\"Delete Profile\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&profile_id=$profid&action=remove'\" type=\"button\">";
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--profile--/$profile/g;
		$inline =~ s/--proflist--/$proflist/g;
		$inline =~ s/--profdel--/$profdel/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# sms and email alarms

if (($uimode eq "userinfo") && ($uismode eq "alarms") && ($uaccess >= $alevel{$uimode.$uismode})) {
	if ($action eq "save") {
		my $newalemail = (exists $FORM{alarms_email})?1:0;
		my $newalsms = (exists $FORM{alarms_sms})?1:0;
		if ($HVAC{"system.notifications_email"} != $newalemail) {
			$HVAC{"system.notifications_email"} = $newalemail;
			dbdo("UPDATE hvac SET value_ = $newalemail WHERE option_ = 'system.notifications_email';", 0);
		}
		if ($HVAC{"system.notifications_sms"} != $newalsms) {
			$HVAC{"system.notifications_sms"} = $newalsms;
			dbdo("UPDATE hvac SET value_ = $newalsms WHERE option_ = 'system.notifications_sms';", 0);
		}
		if ($FORM{en} =~ m/^\w[\w\.\-]*\w\@\w[\w\.\-]*\w(\.\w{2,4})$/) {						# add new email
			my $sever = ((exists $FORM{"gen"})?1:0) + ((exists $FORM{"yen"})?2:0) + ((exists $FORM{"ren"})?4:0);
			dbdo("INSERT INTO notifications VALUES (NULL, '".$FORM{en}."', '', $sever)", 0);
		}
		if ((length($FORM{sn}) > 6) && ($FORM{sn} =~ m/^\d+$/)) {							# add new sms
			my $sever = ((exists $FORM{"gsn"})?1:0) + ((exists $FORM{"ysn"})?2:0) + ((exists $FORM{"rsn"})?4:0);
			dbdo("INSERT INTO notifications VALUES (NULL, '', '".$FORM{sn}."', $sever)", 0);
		}
	}

	if ($action eq "remove") {
		my $remid = $FORM{id} + 0;
		dbdo("DELETE FROM notifications WHERE id = $remid", 0);
	}

	my $lemail = "";
	my $lsms = "";
	my $all = $db->selectall_arrayref("SELECT id, email, phone, severity FROM notifications ORDER BY id");
	foreach my $row (@$all) {
		my ($noid, $email, $phone, $sever) = @$row;
		if ((length($email)) && (defined($email))) {
			if (exists $FORM{"e".$noid}) {
				if ($FORM{"e".$noid} ne $email) {
					if ($FORM{"e".$noid} =~ m/^\w[\w\.\-]*\w\@\w[\w\.\-]*\w(\.\w{2,4})$/) {		# really email?
						$email = $FORM{"e".$noid};
						dbdo("UPDATE notifications SET email='$email' WHERE id=$noid", 0);
					}
				}
				my $nsever = ((exists $FORM{"ge".$noid})?1:0) + ((exists $FORM{"ye".$noid})?2:0) + ((exists $FORM{"re".$noid})?4:0);
				if ($nsever != $sever) {
					$sever = $nsever;
					dbdo("UPDATE notifications SET severity='$sever' WHERE id=$noid", 0);
				}
			}
			$lemail .= "<tr style=\"height:30px\" align=\"center\">
						<td nowrap=\"nowrap\">
							<input name=\"e".$noid."\" size=\"30\" maxlength=\"90\" value=\"$email\" type=\"text\">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"re".$noid."\" type=\"checkbox\" ".((($sever & 4) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"ye".$noid."\" type=\"checkbox\" ".((($sever & 2) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"ge".$noid."\" type=\"checkbox\" ".((($sever & 1) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\"  class=\"noborder\">
							<input name=\"Deletee\"".$noid." value=\"Delete\" onClick=\"window.location.href='./engine.pl?mode=--mode--&submode=--submode--&action=remove&id=$noid';\" type=\"button\">
						</td>
					</tr>";
		}
		if ((length($phone)) && (defined($phone))) {
			if (exists $FORM{"s".$noid}) {
				if ($FORM{"s".$noid} ne $phone) {
					if ((length($FORM{"s".$noid}) > 6) && ($FORM{"s".$noid} =~ m/^\d+$/)) {			# really phone?
						$phone = $FORM{"s".$noid};
						dbdo("UPDATE notifications SET phone='$phone' WHERE id=$noid", 0);
					}
				}
				my $nsever = ((exists $FORM{"gs".$noid})?1:0) + ((exists $FORM{"ys".$noid})?2:0) + ((exists $FORM{"rs".$noid})?4:0);
				if ($nsever != $sever) {
					$sever = $nsever;
					dbdo("UPDATE notifications SET severity='$sever' WHERE id=$noid", 0);
				}
			}
			$lsms .= "<tr style=\"height:30px\" align=\"center\">
						<td nowrap=\"nowrap\">
							<input name=\"s".$noid."\" size=\"30\" maxlength=\"90\" value=\"$phone\" type=\"text\">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"rs".$noid."\" type=\"checkbox\" ".((($sever & 4) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"ys".$noid."\" type=\"checkbox\" ".((($sever & 2) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\">
							<input name=\"gs".$noid."\" type=\"checkbox\" ".((($sever & 1) == 0)?"/":"checked").">
						</td>
						<td nowrap=\"nowrap\"  class=\"noborder\">
							<input name=\"Deletes\"".$noid." value=\"Delete\" onClick=\"window.location.href='./engine.pl?mode=--mode--&submode=--submode--&action=remove&id=$noid';\" type=\"button\">
						</td>
					</tr>";
		}
	}
	$sth->finish;
	undef $all;
	
	my $alemail = ($HVAC{"system.notifications_email"} == 1)?" checked":"";
	my $alsms = ($HVAC{"system.notifications_sms"} == 1)?" checked":"";
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--alarms_email--/$alemail/g;
		$inline =~ s/--alarms_sms--/$alsms/g;
		$inline =~ s/--emails--/$lemail/g;
		$inline =~ s/--smss--/$lsms/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# access password

if (($uimode eq "userinfo") && ($uismode eq "password") && ($uaccess >= $alevel{$uimode.$uismode})) {
        if ($action eq "save") {
		my $oldpass = "TH1SiSMAS4eRPaSS";
		{
       			my $all = $db->selectall_arrayref("SELECT password FROM users WHERE login='$ulogin' LIMIT 1");
			foreach my $row (@$all) {
				($oldpass) = @$row;
			}
			$sth->finish;
			undef $all;
		}
        	my $msgtxt = "Nothing was changed";
        	if ($FORM{username} ne $ulogin) {
        		if ($FORM{username} =~ m/^[a-zA-Z0-9_]*$/) {
        			if (length($FORM{username}) < 6) {
        				$msgtxt = "<font color=red>Username too short!";
        			} else {
					if ($FORM{password_old} ne $oldpass) {
						$msgtxt = "<font color=red>Current password does not match!";
					} else {
						dbdo("UPDATE users SET login='".$FORM{username}."' WHERE login='$ulogin' AND password='".$FORM{password_old}."'", 0);
						$msgtxt = "Username changed successfully";
						$ulogin = $FORM{username};
					}
        			}
        		} else {
        			$msgtxt = "<font color=red>Username contains wrong characters!";
        		}
        	}
        	if (length($FORM{password_new}) > 0) {
        		if ($FORM{password_old} ne $oldpass) {
				$msgtxt = "<font color=red>Current password does not match!";
			} else {
				dbdo("UPDATE users SET password='".$FORM{password_new}."' WHERE login='$ulogin' AND password='".$FORM{password_old}."'", 0);
				$msgtxt = "Password changed successfully";
			}
        	}
        	$message = "<tr><td nowrap=\"nowrap\" width=\"138\">&nbsp;</td><td nowrap=\"nowrap\"><br>$msgtxt</td></tr>\n";
        }
	
	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--username--/$ulogin/g;
		$inline =~ s/--message--/$message/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# smart controller local devices

if (($uimode eq "zonedev") && ($uismode eq "smartdevices") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my ($addr, $maker, $model, $desc) = ("", "", "", "");
	my @relays = ("None", "1", "2", "3", "4", "5", "6");
	my @ifaces = ("ADC", "I2C", "1-wire", "IP", "Zigbee");
	my @alarms = ("Disabled", "Enabled");
	my @severs = ("Green", "Yellow", "Red");
	my @types = ("Flood sensor", "Hot water tank on/off control", "Damper control");
	my ($devlist, $devdel, $ltype, $liface, $lrelay, $lsever, $lalarm) = ("", "", "", "", "", "", "");
	my $devid = (exists $FORM{"device_id"})?($FORM{"device_id"} + 0):-1;
	my ($drelay, $diface, $dalarm, $dsever, $dtype) = (0, 0, 0, 0, 0);		# default values

	if (($action eq "remove") && ($devid > 0)) {
		dbdo("DELETE FROM smartdevices WHERE id = $devid", 0);
		$devid = -1;
	}

	if ($action eq "save") {
		my $ntype = $FORM{type} + 0;
		my $niface = $FORM{interface} + 0;
		my $naddr = $FORM{address}."";
		my $nrelay = $FORM{relay} + 0;
		my $nalarm = $FORM{alarm} + 0;
		my $nsever = $FORM{severity} + 0;
		my $nmaker = $FORM{maker}."";
		my $nmodel = $FORM{model}."";
		my $ndesc = $FORM{description}."";
		if ($devid > 0) {
			dbdo("UPDATE smartdevices SET updated = NOW(), type_ = $ntype, interface = $niface, address = '$naddr', relay = $nrelay, alarm = $nalarm, severity = $nsever, maker = '$nmaker', model = '$nmodel', description = '$ndesc' WHERE id = $devid", 0);
		} else {
			dbdo("INSERT INTO smartdevices VALUES (NULL, NOW(), $ntype, $niface, '$naddr', $nrelay, $nalarm, $nsever, '$nmaker', '$nmodel', '$ndesc')", 0);
			$sth = $db->prepare("SELECT last_insert_id() FROM smartdevices");
			$sth->execute;
				($devid) = $sth->fetchrow_array();
			$sth->finish;
		}
	}

	my %urelay = ();
	{
		$devlist = "<option value=\"-1\" ".(($devid == -1)?"selected=\"selected\"":"").">Define New Device</option>";
		my $all = $db->selectall_arrayref("SELECT id, description, relay FROM smartdevices ORDER BY id");
		foreach my $row (@$all) {
			$devlist .= "<option value=\"".@$row[0]."\" ".(($devid == @$row[0])?"selected=\"selected\"":"").">ID.".@$row[0].((@$row[1] ne "")?": ".@$row[1]:"")."</option>";
			if (@$row[2] > 0) {			# this relay is used already
				$urelay{@$row[2]} = 1;
			}
		}
		$sth->finish;
		undef $all;
	}

	if ($devid > 0) {
		my $all = $db->selectall_arrayref("SELECT type_, interface, address, relay, alarm, severity, maker, model, description FROM smartdevices WHERE id = $devid");
		foreach my $row (@$all) {
			($dtype, $diface, $addr, $drelay, $dalarm, $dsever, $maker, $model, $desc) = (@$row[0], @$row[1], @$row[2], @$row[3], @$row[4], @$row[5], @$row[6], @$row[7], @$row[8]);
		}
		$sth->finish;
		undef $all;
		$devdel = "&nbsp;&nbsp;&nbsp;<input name=\"devdel\" value=\"Delete Device\" onClick=\"window.location.href='./engine.pl?mode=$uimode&submode=$uismode&device_id=$devid&action=remove'\" type=\"button\">";
	}
	for my $idx (0 .. $#relays) {
		if ((!exists $urelay{$idx}) || ($idx == $drelay)) {
			$lrelay .= "<option value=\"$idx\" ".(($idx == $drelay)?" selected=\"selected\"":"").">".$relays[$idx]."</option>";
		}
	}
	for my $idx (0 .. $#ifaces) {
		$liface .= "<option value=\"$idx\" ".(($idx == $diface)?" selected=\"selected\"":"").">".$ifaces[$idx]."</option>";
	}
	for my $idx (0 .. $#types) {
		$ltype .= "<option value=\"$idx\" ".(($idx == $dtype)?" selected=\"selected\"":"").">".$types[$idx]."</option>";
	}
	for my $idx (0 .. $#alarms) {
		$lalarm .= "<option value=\"$idx\" ".(($idx == $dalarm)?" selected=\"selected\"":"").">".$alarms[$idx]."</option>";
	}
	for my $idx (0 .. $#severs) {
		$lsever .= "<option value=\"$idx\" ".(($idx == $dsever)?" selected=\"selected\"":"").">".$severs[$idx]."</option>";
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--devlist--/$devlist/g;
		$inline =~ s/--devdel--/$devdel/g;
		$inline =~ s/--type--/$ltype/g;
		$inline =~ s/--interface--/$liface/g;
		$inline =~ s/--relay--/$lrelay/g;
		$inline =~ s/--description--/$desc/g;
		$inline =~ s/--alarm--/$lalarm/g;
		$inline =~ s/--severity--/$lsever/g;
		$inline =~ s/--address--/$addr/g;
		$inline =~ s/--maker--/$maker/g;
		$inline =~ s/--model--/$model/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# customer details

if (($uimode eq "userinfo") && ($uismode eq "details") && ($uaccess >= $alevel{$uimode.$uismode})) {

	my %provinces = ("NONE", "Not Canada or USA", "CAN-AL", "Alberta", "CAN-BC", "British Columbia", "CAN-MT", "Manitoba", "CAN-NB", "New Brunswick", "CAN-NS", "Nova Scotia", "CAN-ON", "Ontario", "CAN-QB", "Quebec", "CAN-SS", "Saskatchewan", "CAN-PE", "Prince Edward Island", "CAN-NL", "Newfoundland and Labrador", "USA-AL", "Alabama", "USA-AK", "Alaska", "USA-AZ", "Arizona", "USA-AR", "Arkansas", "USA-CA", "California", "USA-CO", "Colorado", "USA-CT", "Connecticut", "USA-DE", "Delaware", "USA-FL", "Florida", "USA-GA", "Georgia", "USA-HI", "Hawaii", "USA-ID", "Idaho", "USA-IL", "Illinois", "USA-IN", "Indiana", "USA-IA", "Iowa", "USA-KS", "Kansas", "USA-KY", "Kentucky", "USA-LA", "Louisiana", "USA-ME", "Maine", "USA-MD", "Maryland", "USA-MA", "Massachusetts", "USA-MI", "Michigan", "USA-MN", "Minnesota", "USA-MS", "Mississippi", "USA-MO", "Missouri", "USA-MT", "Montana", "USA-NE", "Nebraska", "USA-NV", "Nevada", "USA-NH", "New Hampshire", "USA-NJ", "New Jersey", "USA-NM", "New Mexico", "USA-NY", "New York", "USA-NC", "North Carolina", "USA-ND", "North Dakota", "USA-OH", "Ohio", "USA-OK", "Oklahoma", "USA-OR", "Oregon", "USA-PA", "Pennsylvania", "USA-RI", "Rhode Island", "USA-SC", "South Carolina", "USA-SD", "South Dakota", "USA-TN", "Tennessee", "USA-TX", "Texas", "USA-UT", "Utah", "USA-VT", "Vermont", "USA-VA", "Virginia", "USA-WA", "Washington", "USA-WV", "West Virginia", "USA-WI", "Wisconsin", "USA-WY", "Wyoming");
	my %countries = ("Afghanistan", "Afghanistan", "Aland Islands", "Aland Islands", "Albania", "Albania", "Algeria", "Algeria", "American Samoa", "American Samoa", "Andorra", "Andorra", "Angola", "Angola", "Anguilla", "Anguilla", "Antarctica", "Antarctica", "Antigua and Barbuda", "Antigua and Barbuda", "Argentina", "Argentina", "Armenia", "Armenia", "Aruba", "Aruba", "Australia", "Australia", "Austria", "Austria", "Azerbaijan", "Azerbaijan", "Bahamas", "Bahamas", "Bahrain", "Bahrain", "Bangladesh", "Bangladesh", "Barbados", "Barbados", "Belarus", "Belarus", "Belgium", "Belgium", "Belize", "Belize", "Benin", "Benin", "Bermuda", "Bermuda", "Bhutan", "Bhutan", "Bolivia", "Bolivia", "Bosnia and Herzegovina", "Bosnia and Herzegovina", "Botswana", "Botswana", "Bouvet Island", "Bouvet Island", "Brazil", "Brazil", "British Indian Ocean Territory", "British Indian Ocean Territory", "Brunei Darussalam", "Brunei Darussalam", "Bulgaria", "Bulgaria", "Burkina Faso", "Burkina Faso", "Burundi", "Burundi", "Cambodia", "Cambodia", "Cameroon", "Cameroon", "Canada", "Canada", "Cape Verde", "Cape Verde", "Cayman Islands", "Cayman Islands", "Central African Republic", "Central African Republic", "Chad", "Chad", "Chile", "Chile", "China", "China", "Christmas Island", "Christmas Island", "Cocos (Keeling) Islands", "Cocos (Keeling) Islands", "Colombia", "Colombia", "Comoros", "Comoros", "Congo", "Congo", "Cook Islands", "Cook Islands", "Costa Rica", "Costa Rica", "Cote D'ivoire", "Cote D'ivoire", "Croatia", "Croatia", "Cuba", "Cuba", "Cyprus", "Cyprus", "Czech Republic", "Czech Republic", "Denmark", "Denmark", "Djibouti", "Djibouti", "Dominica", "Dominica", "Dominican Republic", "Dominican Republic", "Ecuador", "Ecuador", "Egypt", "Egypt", "El Salvador", "El Salvador", "Equatorial Guinea", "Equatorial Guinea", "Eritrea", "Eritrea", "Estonia", "Estonia", "Ethiopia", "Ethiopia", "Falkland Islands", "Falkland Islands (Malvinas)", "Faroe Islands", "Faroe Islands", "Fiji", "Fiji", "Finland", "Finland", "France", "France", "French Guiana", "French Guiana", "French Polynesia", "French Polynesia", "French Southern Territories", "French Southern Territories", "Gabon", "Gabon", "Gambia", "Gambia", "Georgia", "Georgia", "Germany", "Germany", "Ghana", "Ghana", "Gibraltar", "Gibraltar", "Greece", "Greece", "Greenland", "Greenland", "Grenada", "Grenada", "Guadeloupe", "Guadeloupe", "Guam", "Guam", "Guatemala", "Guatemala", "Guernsey", "Guernsey", "Guinea", "Guinea", "Guinea-bissau", "Guinea-bissau", "Guyana", "Guyana", "Haiti", "Haiti", "Heard Island", "Heard Island and Mcdonald Islands", "Holy See", "Holy See (Vatican City State)", "Honduras", "Honduras", "Hong Kong", "Hong Kong", "Hungary", "Hungary", "Iceland", "Iceland", "India", "India", "Indonesia", "Indonesia", "Iran", "Iran, Islamic Republic of", "Iraq", "Iraq", "Ireland", "Ireland", "Isle of Man", "Isle of Man", "Israel", "Israel", "Italy", "Italy", "Jamaica", "Jamaica", "Japan", "Japan", "Jersey", "Jersey", "Jordan", "Jordan", "Kazakhstan", "Kazakhstan", "Kenya", "Kenya", "Kiribati", "Kiribati", "Korea Democratic People Republic", "Korea, Democratic People's Republic of", "Korea Republic", "Korea, Republic of", "Kuwait", "Kuwait", "Kyrgyzstan", "Kyrgyzstan", "Laos", "Lao People's Democratic Republic", "Latvia", "Latvia", "Lebanon", "Lebanon", "Lesotho", "Lesotho", "Liberia", "Liberia", "Libyan Arab Jamahiriya", "Libyan Arab Jamahiriya", "Liechtenstein", "Liechtenstein", "Lithuania", "Lithuania", "Luxembourg", "Luxembourg", "Macao", "Macao", "Macedonia", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Madagascar", "Malawi", "Malawi", "Malaysia", "Malaysia", "Maldives", "Maldives", "Mali", "Mali", "Malta", "Malta", "Marshall Islands", "Marshall Islands", "Martinique", "Martinique", "Mauritania", "Mauritania", "Mauritius", "Mauritius", "Mayotte", "Mayotte", "Mexico", "Mexico", "Micronesia", "Micronesia, Federated States of", "Moldova", "Moldova, Republic of", "Monaco", "Monaco", "Mongolia", "Mongolia", "Montenegro", "Montenegro", "Montserrat", "Montserrat", "Morocco", "Morocco", "Mozambique", "Mozambique", "Myanmar", "Myanmar", "Namibia", "Namibia", "Nauru", "Nauru", "Nepal", "Nepal", "Netherlands", "Netherlands", "Netherlands Antilles", "Netherlands Antilles", "New Caledonia", "New Caledonia", "New Zealand", "New Zealand", "Nicaragua", "Nicaragua", "Niger", "Niger", "Nigeria", "Nigeria", "Niue", "Niue", "Norfolk Island", "Norfolk Island", "Northern Mariana Islands", "Northern Mariana Islands", "Norway", "Norway", "Oman", "Oman", "Pakistan", "Pakistan", "Palau", "Palau", "Palestinian Territory", "Palestinian Territory, Occupied", "Panama", "Panama", "Papua New Guinea", "Papua New Guinea", "Paraguay", "Paraguay", "Peru", "Peru", "Philippines", "Philippines", "Pitcairn", "Pitcairn", "Poland", "Poland", "Portugal", "Portugal", "Puerto Rico", "Puerto Rico", "Qatar", "Qatar", "Reunion", "Reunion", "Romania", "Romania", "Russian Federation", "Russian Federation", "Rwanda", "Rwanda", "Saint Helena", "Saint Helena", "Saint Kitts and Nevis", "Saint Kitts and Nevis", "Saint Lucia", "Saint Lucia", "Saint Pierre and Miquelon", "Saint Pierre and Miquelon", "Saint Vincent and The Grenadines", "Saint Vincent and The Grenadines", "Samoa", "Samoa", "San Marino", "San Marino", "Sao Tome and Principe", "Sao Tome and Principe", "Saudi Arabia", "Saudi Arabia", "Senegal", "Senegal", "Serbia", "Serbia", "Seychelles", "Seychelles", "Sierra Leone", "Sierra Leone", "Singapore", "Singapore", "Slovakia", "Slovakia", "Slovenia", "Slovenia", "Solomon Islands", "Solomon Islands", "Somalia", "Somalia", "South Africa", "South Africa", "South Georgia", "South Georgia and The South Sandwich Islands", "Spain", "Spain", "Sri Lanka", "Sri Lanka", "Sudan", "Sudan", "Suriname", "Suriname", "Svalbard and Jan Mayen", "Svalbard and Jan Mayen", "Swaziland", "Swaziland", "Sweden", "Sweden", "Switzerland", "Switzerland", "Syrian Arab Republic", "Syrian Arab Republic", "Taiwan", "Taiwan, Province of China", "Tajikistan", "Tajikistan", "Tanzania", "Tanzania, United Republic of", "Thailand", "Thailand", "Timor-leste", "Timor-leste", "Togo", "Togo", "Tokelau", "Tokelau", "Tonga", "Tonga", "Trinidad and Tobago", "Trinidad and Tobago", "Tunisia", "Tunisia", "Turkey", "Turkey", "Turkmenistan", "Turkmenistan", "Turks and Caicos Islands", "Turks and Caicos Islands", "Tuvalu", "Tuvalu", "Uganda", "Uganda", "Ukraine", "Ukraine", "United Arab Emirates", "United Arab Emirates", "United Kingdom", "United Kingdom", "United States", "United States", "United States Minor Outlying Islands", "United States Minor Outlying Islands", "Uruguay", "Uruguay", "Uzbekistan", "Uzbekistan", "Vanuatu", "Vanuatu", "Venezuela", "Venezuela", "Viet Nam", "Viet Nam", "Virgin Islands, British", "Virgin Islands, British", "Virgin Islands, U.S.", "Virgin Islands, U.S.", "Wallis and Futuna", "Wallis and Futuna", "Western Sahara", "Western Sahara", "Yemen", "Yemen", "Zambia", "Zambia", "Zimbabwe", "Zimbabwe");
	my @timezones = ("(GMT-12:00) International Date Line West", "(GMT-11:00) Mixxxay Island, Samoa", "(GMT-10:00) Hawaii", "(GMT-09:00) Alaska", "(GMT-08:00) Pacific Time (USA &amp; Canada)", "(GMT-07:00) Arizona", "(GMT-07:00) Mountain Time (USA &amp; Canada)", "(GMT-06:00) Central America", "(GMT-06:00) Central Time (USA &amp; Canada)", "(GMT-06:00) Guadalajara, Mexico City, Monterrey", "(GMT-06:00) Saskatchewan", "(GMT-05:00) Bogota, Lima, Quito", "(GMT-05:00) Eastern Time (USA &amp; Canada)", "(GMT-05:00) Indiana (East)", "(GMT-04:00) Atlantic Time (Canada)", "(GMT-04:00) Caracas, La Paz", "(GMT-04:00) Santiago", "(GMT-03:30) Newfoundland", "(GMT-03:00) Brasilia", "(GMT-03:00) Buenos Aires, Georgetown", "(GMT-03:00) Greenland", "(GMT-02:00) Mid-Atlantic", "(GMT-01:00) Azores", "(GMT-01:00) Cape Verde ls.", "(GMT) Casablanca, Monrovia", "(GMT) Greenwich Mean Time: Dublin, Edinburgh, Lisbon, London", "(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna", "(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague", "(GMT+01:00) Brussels, Copenhagen, Madrid, Paris", "(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb", "(GMT+01:00) West Central Africa", "(GMT+02:00) Athens, Istanbul, Minsk", "(GMT+02:00) Bucharest", "(GMT+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius", "(GMT+02:00) Jerusalem", "(GMT+03:00) Baghdad", "(GMT+03:00) Moscow, St. Petersburg, Volgograd", "(GMT+03:00) Nairobi", "(GMT+03:30) Tehran", "(GMT+04:00) Abu Dhabi, Muscat", "(GMT+04:30) Kabul", "(GMT+05:00) Ekaterinburg", "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi", "(GMT+05:45) Kathmandu", "(GMT+06:00) Almaty, Novosibirsk", "(GMT+06:00) Astana, Dhaka", "(GMT+06:30) Rangoon", "(GMT+07:00) Bangkok, Hanoi, Jakarta", "(GMT+07:00) Krasnoyarsk", "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi", "(GMT+08:00) Irkutsk, Ulaan Bataar", "(GMT+08:00) Kuala Lumpur, Singapore", "(GMT+08:00) Taipei", "(GMT+09:00) Osaka, Sapporo, Tokyo", "(GMT+09:00) Seoul", "(GMT+09:30) Adelaide", "(GMT+10:00) Brisbane", "(GMT+10:00) Vladivostok", "(GMT+11:00) Magadan, Solomon Is., New Caledonia", "(GMT+12:00) Auckland, Wellington", "(GMT+12:00) Fiji, Kamchatka, Marshall Is.", "(GMT+13:00) Nuku'alofa");

	if (($action eq "save") && ($clientid > 0)) {
		dbdo("UPDATE users SET city='".$FORM{city}."', province='".$FORM{province}."', country='".$FORM{country}."', postal='".$FORM{postal}."', phone1='".$FORM{phone1}."', phone2='".$FORM{phone2}."', phone3='".$FORM{phone3}."', email='".$FORM{email}."', timezone='".($FORM{timezone} + 0)."', comfort='".($FORM{comfort} + 0)."', t_display='".($FORM{t_display} + 0)."', name1='".$FORM{name1}."', name2='".$FORM{name2}."', address1='".$FORM{address1}."', address2='".$FORM{address2}."' WHERE id = $clientid", 0);
		if (($FORM{name1} eq "") || ($FORM{name2} eq "") || ($FORM{address1} eq "") || ($FORM{city} eq "") || ($FORM{postal} eq "") || ($FORM{email} eq "")) {
			$message = "<tr><td nowrap=\"nowrap\" width=\"138\">&nbsp;</td><td nowrap=\"nowrap\"><font color=red><br>One or more important fields must be filled!</td></tr>\n";
		}
	}
        
        my $comfort = 0;
        my @lcomfort = ("", "", "", "", "");
        my $tdisplay = 0;
        my @ltdisp = ("", "");
        my $timezone = 0;
        my ($ltimezone, $province, $lprovince, $country, $lcountry) = ("", "", "", "", "");
        my ($name1, $name2, $email, $phone1, $phone2, $phone3, $postal, $city, $address1, $address2) = ("", "", "", "", "", "", "", "", "", "");
	my $all = $db->selectall_arrayref("SELECT comfort, t_display, timezone, province, country, name1, name2, email, phone1, phone2, phone3, postal, city, address1, address2 FROM users WHERE id = $clientid ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		$comfort = @$row[0] + 0;
		$lcomfort[$comfort] = "checked=\"checked\"";
		$tdisplay = @$row[1] + 0;
		$ltdisp[$tdisplay] = "checked=\"checked\"";
		$timezone = @$row[2] + 0;
		$province = @$row[3];
		$country = @$row[4];
		$name1 = @$row[5];
		$name2 = @$row[6];
		$email = @$row[7];
		$phone1 = @$row[8];
		$phone2 = @$row[9];
		$phone3 = @$row[10];
		$postal = @$row[11];
		$city = @$row[12];
		$address1 = @$row[13];
		$address2 = @$row[14];
	}
	$sth->finish;
	undef $all;

	foreach my $iprovince (sort keys %provinces) {
		$lprovince .= "<option value=\"$iprovince\"".(($province eq $iprovince)?" selected=\"selected\"":"").">".$provinces{$iprovince}."</option>";
	}
	foreach my $icountry (sort keys %countries) {
		$lcountry .= "<option value=\"$icountry\"".(($country eq $icountry)?" selected=\"selected\"":"").">".$countries{$icountry}."</option>";
	}
	for my $itimezone (0 .. $#timezones) {
		$ltimezone .= "<option value=\"".$itimezone."\" ".(($itimezone == $timezone)?" selected=\"selected\"":"").">".$timezones[$itimezone]."</option>";
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--email--/$email/g;
		$inline =~ s/--name1--/$name1/g;
		$inline =~ s/--name2--/$name2/g;
		$inline =~ s/--phone1--/$phone1/g;
		$inline =~ s/--phone2--/$phone2/g;
		$inline =~ s/--phone3--/$phone3/g;
		$inline =~ s/--postal--/$postal/g;
		$inline =~ s/--city--/$city/g;
		$inline =~ s/--address1--/$address1/g;
		$inline =~ s/--address2--/$address2/g;
		$inline =~ s/--t_display0--/$ltdisp[0]/g;
		$inline =~ s/--t_display1--/$ltdisp[1]/g;
		$inline =~ s/--comfort0--/$lcomfort[0]/g;
		$inline =~ s/--comfort1--/$lcomfort[1]/g;
		$inline =~ s/--comfort2--/$lcomfort[2]/g;
		$inline =~ s/--comfort3--/$lcomfort[3]/g;
		$inline =~ s/--comfort4--/$lcomfort[4]/g;
		$inline =~ s/--timezone--/$ltimezone/g;
		$inline =~ s/--province--/$lprovince/g;
		$inline =~ s/--country--/$lcountry/g;
		$inline =~ s/--message--/$message/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# events and alarms viewer

if (($uimode eq "events") && ($uismode eq "events") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my $evtype = (exists $FORM{evtype})?$FORM{evtype}:0;
	my $severity = (exists $FORM{severity})?$FORM{severity}:3;
	my @sevlist = ("Green", "Yellow", "Red", "Show All");
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt, $levtype, $lseverity, $evlist) = ("", "", "", "", "", "", "", "", "", "");

	my $all = $db->selectall_arrayref("SELECT type_, description FROM alarms_types WHERE alarm_id = -1 ORDER BY type_");
	foreach my $row (@$all) {
		my ($altype, $aldesc) = @$row;
		$levtype .= "<option value=\"$altype\"".(($altype == $evtype)?" selected=\"selected\"":"").">$aldesc</option>";
	}
	$sth->finish;
	undef $all;

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	for my $sevv (0 .. $#sevlist) {
		$lseverity .= "<option value=\"$sevv\"".(($severity == $sevv)?" selected=\"selected\"":"").">".$sevlist[$sevv]."</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);

	# other type events viewer TBD!!

	if ($evtype == 5) {					# view registration events
		my %alist = ();
		my %asevr = ();
		my $all = $db->selectall_arrayref("SELECT alarm_id, severity, description FROM alarms_types WHERE type_ = 5 AND alarm_id >= 0");		# only reg alarms list
		foreach my $row (@$all) {
			my ($alid, $alsev, $aldesc) = @$row;
			$alist{$alid} = $aldesc;
			$asevr{$alid} = $alsev;
		}
		$sth->finish;
		undef $all;

		my @regstat = ("Pending", "Inactive", "Accepted", "Rejected");
		my $all = $db->selectall_arrayref("SELECT DATE_FORMAT(updated, '%b %e, %H:%i'), event_type, device_type, status FROM registrations WHERE updated BETWEEN $datef AND $datet ORDER BY id DESC");
		foreach my $row (@$all) {
			my ($update, $evtype, $devtype, $rstat) = @$row;
			if (($severity > 2) || ($asevr{$evtype} == $severity)) {
				$evlist .= "<tr><td nowrap=\"nowrap\" width=\"80\">$update</td>
						<td class=\"stdbold\" width=\"50\">".$sevlist[$asevr{$evtype}]."</td>
						<td>".$alist{$evtype}.(($evtype == 1)?": ".$regstat[$rstat]:"")."</td></tr>\n";
			}
		}
		$sth->finish;
		undef $all;
	}

	if ($evlist eq "") {
		$evlist = "<tr><td nowrap=\"nowrap\" width=\"120\">No events to display</td>
				<td class=\"stdbold\" width=\"50\"></td>
				<td></td></tr>\n";
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--events--/$evlist/g;
		$inline =~ s/--severity--/$lseverity/g;
		$inline =~ s/--evtype--/$levtype/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# network events and alarms management

if (($uimode eq "events") && ($uismode eq "management") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my @severity = ("Green", "Yellow", "Red");
	my @alarms = ("", "", "", "", "", "");

	my $all = $db->selectall_arrayref("SELECT id, status, severity, description, type_ FROM alarms_types WHERE alarm_id >= 0 AND (type_ = 3 OR type_ = 5 OR type_ = 1) ORDER BY type_, id");
	foreach my $row (@$all) {
		my ($alid, $alst, $alsev, $aldesc, $altype) = @$row;
		if ($action eq "save") {
			if (exists $FORM{"alst".$alid}) {
				if ($FORM{"alst".$alid} != $alst) {
					$alst = $FORM{"alst".$alid} + 0;
					dbdo("UPDATE alarms_types SET status = '$alst' WHERE id = $alid", 0);
				}
			}
		}		
		$alarms[$altype] .= "<tr><td nowrap=\"nowrap\" width=\"220\">$aldesc</td>";
		if ($uaccess > 0) {
			if ($action eq "save") {
				if (exists $FORM{"alsev".$alid}) {
					if ($FORM{"alsev".$alid} != $alsev) {
						$alsev = $FORM{"alsev".$alid} + 0;
						dbdo("UPDATE alarms_types SET severity = '$alsev' WHERE id = $alid", 0);
					}
				}
			}
			my $sevtxt = "<select name=\"alsev".$alid."\" size=\"1\">";
			for my $sevv (0 .. $#severity) {
				$sevtxt .= "<option value=\"$sevv\"".(($alsev == $sevv)?" selected=\"selected\"":"").">".$severity[$sevv]."</option>";
			}
			$alarms[$altype] .= "<td nowrap=\"nowrap\" width=70>$sevtxt</select></td>";
		} else {
			$alarms[$altype] .= "<td class=\"stdbold\" nowrap=\"nowrap\" width=70>&nbsp;&nbsp;&nbsp;".$severity[$alsev]."</td>";
		}
		$alarms[$altype] .= "<td nowrap=\"nowrap\"><select name=\"alst".$alid."\" size=\"1\"><option value=\"0\"".(($alst == 0)?" selected=\"selected\"":"").">Disabled</option><option value=\"1\"".(($alst == 1)?" selected=\"selected\"":"").">Enabled</option></select></td></tr>";
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--alarms_zigbee--/$alarms[1]/g;
		$inline =~ s/--alarms_net--/$alarms[3]/g;
		$inline =~ s/--alarms_reg--/$alarms[5]/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# system events and alarms management

if (($uimode eq "events") && ($uismode eq "alarms") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my @severity = ("Green", "Yellow", "Red");
	my @alarms = ("", "", "", "", "", "");

	my $all = $db->selectall_arrayref("SELECT id, status, severity, description, type_ FROM alarms_types WHERE alarm_id >= 0 AND (type_ = 0 OR type_ = 2 OR type_ = 4) ORDER BY type_, id");
	foreach my $row (@$all) {
		my ($alid, $alst, $alsev, $aldesc, $altype) = @$row;
		if ($action eq "save") {
			if (exists $FORM{"alst".$alid}) {
				if ($FORM{"alst".$alid} != $alst) {
					$alst = $FORM{"alst".$alid} + 0;
					dbdo("UPDATE alarms_types SET status = '$alst' WHERE id = $alid", 0);
				}
			}
		}
		$alarms[$altype] .= "<tr><td nowrap=\"nowrap\" width=\"220\">$aldesc</td>";
		if ($uaccess > 0) {
			if ($action eq "save") {
				if (exists $FORM{"alsev".$alid}) {
					if ($FORM{"alsev".$alid} != $alsev) {
						$alsev = $FORM{"alsev".$alid} + 0;
						dbdo("UPDATE alarms_types SET severity = '$alsev' WHERE id = $alid", 0);
					}
				}
			}
			my $sevtxt = "<select name=\"alsev".$alid."\" size=\"1\">";
			for my $sevv (0 .. $#severity) {
				$sevtxt .= "<option value=\"$sevv\"".(($alsev == $sevv)?" selected=\"selected\"":"").">".$severity[$sevv]."</option>";
			}
			$alarms[$altype] .= "<td nowrap=\"nowrap\" width=70>$sevtxt</select></td>";
		} else {
			$alarms[$altype] .= "<td class=\"stdbold\" nowrap=\"nowrap\" width=70>&nbsp;&nbsp;&nbsp;".$severity[$alsev]."</td>";
		}
		$alarms[$altype] .= "<td nowrap=\"nowrap\"><select name=\"alst".$alid."\" size=\"1\"><option value=\"0\"".(($alst == 0)?" selected=\"selected\"":"").">Disabled</option><option value=\"1\"".(($alst == 1)?" selected=\"selected\"":"").">Enabled</option></select></td></tr>";
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--alarms_sys--/$alarms[2]/g;
		$inline =~ s/--alarms_pressure--/$alarms[4]/g;
		$inline =~ s/--alarms_save--/$alarms[0]/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# software update page

if (($uimode eq "system") && ($uismode eq "update") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $updmsg = "";
	if ($action eq "save") {				# update check TBD
		$updmsg = "<tr><td colspan=2><br>No updates currently available</td></tr>\n";
	}

        my ($cloud1, $cloud2) = ("", "");
	my $all = $db->selectall_arrayref("SELECT cloud1, cloud2, id FROM networks ORDER BY id DESC LIMIT 1");
	foreach my $row (@$all) {
		($cloud1, $cloud2) = (@$row[0], @$row[1]);
	}
	$sth->finish;
	undef $all;

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--sw_version--/$version/g;
		$inline =~ s/--cloud1--/$cloud1/g;
		$inline =~ s/--cloud2--/$cloud2/g;
		$inline =~ s/--updmessage--/$updmsg/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# database maintenance page

if (($uimode eq "system") && ($uismode eq "db") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $maxdays = (exists $HVAC{"system.max_days"})?$HVAC{"system.max_days"}:30;
	my $maxstrv = (exists $HVAC{"system.max_storage"})?$HVAC{"system.max_storage"}:0;
	my @maxstor = ("", "");

	if (($action eq "save") && (exists $FORM{max_days}) && (exists $FORM{max_storage})) {
		my $newmaxdays = $FORM{max_days} + 0;
		if ($maxdays != $newmaxdays) {
			$maxdays = $newmaxdays;
			dbdo("UPDATE hvac SET value_ = $maxdays WHERE option_ = 'system.max_days';", 0);
		}
		my $newmaxstor = $FORM{max_storage} + 0;
		if ($maxstrv != $newmaxstor) {
			$maxstrv = $newmaxstor;
			dbdo("UPDATE hvac SET value_ = $maxstrv WHERE option_ = 'system.max_storage';", 0);
		}
	}
	$maxstor[$maxstrv] = " checked=\"checked\"";

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--max_days--/$maxdays/g;
		$inline =~ s/--max_storage0--/$maxstor[0]/g;
		$inline =~ s/--max_storage1--/$maxstor[1]/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# occupancy schedule report

if (($uimode eq "reports") && ($uismode eq "occupancy") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my $zone = (exists $FORM{zone})?$FORM{zone}:2;
	my $bout = (exists $FORM{breakout})?$FORM{breakout}:1;
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my ($lzone, $lbreak, $loccup) = ("", "", "");

	for my $breaks (0 .. 1) {
		$lbreak .= "<option value=\"$breaks\"".(($bout == $breaks)?" selected=\"selected\"":"").">".(($breaks + 1) * 15)."</option>";	# 15 min increment
	}
	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);

	{
		my $all = $db->selectall_arrayref("SELECT id, description FROM zones WHERE id > 1 ORDER BY id");
		foreach my $row (@$all) {
			$lzone .= "<option value=\"".@$row[0]."\"".((@$row[0] == $zone)?" selected=\"selected\"":"").">".@$row[1]."</option>";
		}
		$sth->finish;
		undef $all;
	}

	for my $ampm (0 .. 1) {
		for (my $hcnt = 0; $hcnt < 720; $hcnt += (($bout + 1) * 15)) {
			my $hfrom = floor($hcnt / 60);
			my $hrto = floor(($hcnt + (($bout + 1) * 15)) / 60);
			my $mfrom = $hcnt - ($hfrom * 60);
			my $minto = ($hcnt + (($bout + 1) * 15)) - ($hrto * 60);
			if ($hfrom == 0) {
				$hfrom = 12;
			}
			if ($hrto == 0) {
				$hrto = 12;
			}
			$loccup .= "<tr><td class=\"stdbold\" align=center>".sprintf("%02d:%02d - %02d:%02d", $hfrom, $mfrom, $hrto, $minto)." ".(($ampm == 0)?"AM":"PM")."</td><td align=center>0%</td><td align=center>0%</td><td align=center>0%</td><td align=center>0%</td><td align=center>0%</td><td align=center>0%</td><td align=center>0%</td></tr>\n";
		}
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--zone--/$lzone/g;
		$inline =~ s/--occupancy--/$loccup/g;
		$inline =~ s/--breakout--/$lbreak/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# charts

if (($uimode eq "reports") && ($uismode eq "charts") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my $zone = (exists $FORM{zone})?$FORM{zone}:2;
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my ($lzone, $chart, $czname) = ("", "", "");

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);

	{
		my $all = $db->selectall_arrayref("SELECT id, description FROM zones WHERE id > 1 ORDER BY id");
		foreach my $row (@$all) {
			$lzone .= "<option value=\"".@$row[0]."\"".((@$row[0] == $zone)?" selected=\"selected\"":"").">".@$row[1]."</option>";
			if (@$row[0] == $zone) {
				$czname = @$row[1];
			}
		}
		$sth->finish;
		undef $all;
	}

	my ($zonet, $zoneh, $tsensor, $hsensor) = ("N/A", "N/A", "Unavailable", "Unavailable");
	if ($czname ne "") {
#		use GD::Graph::lines;
		my $picname = $clientid."-$curyear$curmon$curday$curhour$curmin$cursec.png";
		my $picfile = $selfpath."charts/".$picname;
		my ($udatef, $udatet) = (0, 0);

		my $all = $db->selectall_arrayref("SELECT UNIX_TIMESTAMP($datef), UNIX_TIMESTAMP($datet)");
		foreach my $row (@$all) {
			if (@$row[0] < @$row[1]) {
				($udatef, $udatet) = (@$row[0], @$row[1]);
			} else {
				($udatef, $udatet) = (@$row[1], @$row[0]);		# fool check ))
			}
		}
		$sth->finish;
		undef $all;

		my $all = $db->selectall_arrayref("SELECT AVG(paramsensordyn.temperature), AVG(paramsensordyn.humidity), devices.description FROM paramsensordyn, devices WHERE paramsensordyn.device_id = devices.id AND devices.zone_id = $zone AND devices.device_type = 1");
		foreach my $row (@$all) {
			$zonet = (@$row[0] ne "")?(@$row[0]."&deg;C"):"N/A";
			$zoneh = (@$row[1] ne "")?(@$row[1]."%"):"N/A";
			$tsensor = (@$row[2] ne "")?(@$row[2]):"Unlabeled";
			$hsensor = (@$row[2] ne "")?(@$row[2]):"Unlabeled";
		}
		$sth->finish;
		undef $all;

		my $iters = 30;						# number of iteratio points
		my $idatp = 2;						# date placement per iteration
		my $dincr = floor(($udatet - $udatef) / $iters);	# seconds increment
		my $idatr = 0;						# date placement counter
		my @datemarks = ();
		my @dbgtemp = ();					# temperature debug only!
		my @dbghum = ();					# hum --//--
		for my $datper (0 .. $iters) {
			my ($dmsec,$dmmin,$dmhr,$dmday,$dmmon,$dmyr) = localtime(($datper * $dincr) + $udatef);
			$dmmon += 1;
			$dmyr += 1900;
			if ($idatr == 0) {
				$datemarks[$datper] = sprintf("%02d-%02d-%02d %02d:%02d", ($dmyr - 2000), $dmmon, $dmday, $dmhr, $dmmin); 
				$idatr = $idatp;
			} else {
				$datemarks[$datper] = "-";
				$idatr--;
			}
			$dbgtemp[$datper] = (floor(rand(40)) / 10) + 18;		# 18 - 24 deg fluct
			$dbghum[$datper] = floor(rand(20)) + 30;			# 30 - 70% fluct
		}
		my @data = ( 
		    [@datemarks],
		    [@dbgtemp],
		    [@dbghum],
		  );
		
		my $graph = GD::Graph::lines->new(500, 500);
		$czname =~ s/\szone$//i;
		$graph->set( 
			title		=> "$czname zone graph",
			two_axes	=> 1,
			use_axis	=> [1,2,1],
			x_label		=> '',
			y1_label	=> '',
			y1_min_value	=> 0,
			y1_max_value	=> 28,
			y_tick_number	=> 16,
			y_label_skip	=> 2,
			y2_label	=> '',
			y2_min_value	=> 0,
			y2_max_value	=> 100,
			x_labels_vertical	=> 1
		) or die $graph->error;
		my $gd = $graph->plot(\@data) or die $graph->error;
		open(IMG, ">$picfile") or die $!;
		binmode IMG;
		print IMG $gd->png;
		$chart = "<img src=\"charts/$picname\" border=0 width=500 height=500>";
		close(IMG);
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--t_sensor--/$tsensor/g;
		$inline =~ s/--h_sensor--/$hsensor/g;
		$inline =~ s/--zone--/$lzone/g;
		$inline =~ s/--chart--/$chart/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# COTS charts

if (($uimode eq "reports") && ($uismode eq "cots") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my $line = (exists $FORM{line})?$FORM{line}:"w1";
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my @linames = ("w1", "w2", "y1", "y2", "g", "ob");
	my ($lilist, $chart) = ("", "");
	foreach my $liitem (@linames) {
		$lilist .= "<option value=\"$liitem\"".(($liitem eq $line)?" selected=\"selected\"":"").">".uc($liitem)."</option>";
	}

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);

	my $czname = uc($line);
	if ($czname ne "") {
#		use GD::Graph::lines;
		my $picname = $clientid."-$line-$curyear$curmon$curday$curhour$curmin$cursec.png";
		my $picfile = $selfpath."charts/".$picname;
		my ($udatef, $udatet) = (0, 0);

		my $all = $db->selectall_arrayref("SELECT UNIX_TIMESTAMP($datef), UNIX_TIMESTAMP($datet)");
		foreach my $row (@$all) {
			if (@$row[0] < @$row[1]) {
				($udatef, $udatet) = (@$row[0], @$row[1]);
			} else {
				($udatef, $udatet) = (@$row[1], @$row[0]);		# fool check ))
			}
		}
		$sth->finish;
		undef $all;

		my $iters = 52;						# number of iteratio points
		my $idatp = 3;						# date placement per iteration
		my $dincr = floor(($udatet - $udatef) / $iters);	# seconds increment
		my $idatr = 0;						# date placement counter
		my @datemarks = ();
		my @dbgtemp = ();					# temperature debug only!
		my @dbghum = ();					# hum --//--
		for my $datper (0 .. $iters) {
			my ($dmsec,$dmmin,$dmhr,$dmday,$dmmon,$dmyr) = localtime(($datper * $dincr) + $udatef);
			$dmmon += 1;
			$dmyr += 1900;
			if ($idatr == 0) {
				$datemarks[$datper] = sprintf("%02d-%02d-%02d %02d:%02d", ($dmyr - 2000), $dmmon, $dmday, $dmhr, $dmmin); 
				$idatr = $idatp;
			} else {
				$datemarks[$datper] = "-";
				$idatr--;
			}
			$dbgtemp[$datper] = (floor(rand(40)) / 20) + 20 + (abs($datper - ($iters / 2)) * 0.13);			# some random values
			$dbghum[$datper] = floor(rand(1) + 0.5) * 8 + 1;			# 1 to 9
		}
		my @data = ( 
		    [@datemarks],
		    [@dbgtemp],
		    [@dbghum],
		  );
		
		my $graph = GD::Graph::lines->new(500, 500);			# uses twax_y2 that needs GD::Graph::axestype.pm fix
		$graph->set( 
			title		=> "$czname line graph",
			two_axes	=> 1,
			use_axis	=> [1,2,1],
			line_types	=> [1,1],
			x_label		=> '',
			y1_label	=> '',
			y1_min_value	=> 0,
			y1_max_value	=> 28,
			y_tick_number	=> 16,
			y_label_skip	=> 2,
			y2_label	=> 'LOW              Thermostat line state              HIGH',
			y2_min_value	=> 0,
			y2_max_value	=> 10,
			twax_y2		=> 0,
			x_labels_vertical	=> 1
		) or die $graph->error;
		my $gd = $graph->plot(\@data) or die $graph->error;
		open(IMG, ">$picfile") or die $!;
		binmode IMG;
		print IMG $gd->png;
		$chart = "<img src=\"charts/$picname\" border=0 width=500 height=500>";
		close(IMG);
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--line--/$lilist/g;
		$inline =~ s/--line_sel--/$czname/g;
		$inline =~ s/--chart--/$chart/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# retrosave and bypass runtime report

if (($uimode eq "reports") && ($uismode eq "retrosave") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my ($totdays) = ("");
	my ($rsaveA, $bpassA) = ("", "");
	my ($rrsave, $rbpass) = (0, 0);				# runtime in seconds
	my ($rsaveB, $bpassB) = (0, 0);				# runtime in percent

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);
	my ($udatef, $udatet) = (0, 0);

	{	# calc of date period
		my $all = $db->selectall_arrayref("SELECT UNIX_TIMESTAMP($datef), UNIX_TIMESTAMP($datet)");
		foreach my $row (@$all) {
			if (@$row[0] < @$row[1]) {
				($udatef, $udatet) = (@$row[0], @$row[1]);
			} else {
				($udatef, $udatet) = (@$row[1], @$row[0]);		# fool check ))
			}
		}
		$sth->finish;
		undef $all;
		$totdays = BreakSec($udatet - $udatef);
	}

	{
		# retrosave / bypass stats TDB

		$rsaveA = BreakSec($rrsave);
		$bpassA = BreakSec($rbpass);
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--totaldays--/$totdays/g;
		$inline =~ s/--retrosave_A--/$rsaveA/g;
		$inline =~ s/--bypass_A--/$bpassA/g;
		$inline =~ s/--retrosave_B--/$rsaveB/g;
		$inline =~ s/--bypass_B--/$bpassB/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# hvac runtime report

if (($uimode eq "reports") && ($uismode eq "runtime") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my ($totdays) = ("");
	my @rhvac = ("", "", "", "", "", "", "");						# hum, w1, w2, y1, y2, g, ob
	my @rrhvac = (0, 0, 0, 0, 0, 0, 0);
	my @rphvac = (0, 0, 0, 0, 0, 0, 0);

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);
	my ($udatef, $udatet) = (0, 0);

	{	# calc of date period
		my $all = $db->selectall_arrayref("SELECT UNIX_TIMESTAMP($datef), UNIX_TIMESTAMP($datet)");
		foreach my $row (@$all) {
			if (@$row[0] < @$row[1]) {
				($udatef, $udatet) = (@$row[0], @$row[1]);
			} else {
				($udatef, $udatet) = (@$row[1], @$row[0]);		# fool check ))
			}
		}
		$sth->finish;
		undef $all;
		$totdays = BreakSec($udatet - $udatef);
	}

	{
		# hardware stats TBD

		for my $irhvac (0 .. $#rhvac) {
			$rhvac[$irhvac] = BreakSec($rrhvac[$irhvac]);
		}
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--totaldays--/$totdays/g;
		$inline =~ s/--humidifier_A--/$rhvac[0]/g;
		$inline =~ s/--w1_A--/$rhvac[1]/g;
		$inline =~ s/--w2_A--/$rhvac[2]/g;
		$inline =~ s/--y1_A--/$rhvac[3]/g;
		$inline =~ s/--y2_A--/$rhvac[4]/g;
		$inline =~ s/--g_A--/$rhvac[5]/g;
		$inline =~ s/--ob_A--/$rhvac[6]/g;
		$inline =~ s/--humidifier_B--/$rphvac[0]/g;
		$inline =~ s/--w1_B--/$rphvac[1]/g;
		$inline =~ s/--w2_B--/$rphvac[2]/g;
		$inline =~ s/--y1_B--/$rphvac[3]/g;
		$inline =~ s/--y2_B--/$rphvac[4]/g;
		$inline =~ s/--g_B--/$rphvac[5]/g;
		$inline =~ s/--ob_B--/$rphvac[6]/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# retrosave and bypass runtime report

if (($uimode eq "reports") && ($uismode eq "savings") && ($uaccess >= $alevel{$uimode.$uismode})) {
	my $yearf = (exists $FORM{year_f})?$FORM{year_f}:$curyear;
	my $yeart = (exists $FORM{year_t})?$FORM{year_t}:$curyear;
	my $monthf = (exists $FORM{month_f})?$FORM{month_f}:$curmon;
	my $montht = (exists $FORM{month_t})?$FORM{month_t}:$curmon;
	my $dayf = (exists $FORM{day_f})?$FORM{day_f}:$curday;
	my $dayt = (exists $FORM{day_t})?$FORM{day_t}:$curday;
	my ($lyearf, $lyeart, $lmonthf, $lmontht, $ldayf, $ldayt) = ("", "", "", "", "", "");
	my ($elused, $elsaved) = ("", "");
	my ($relused, $relsaved) = (0, 0);				# electricity in Watt

	for my $year (2014 .. 2024) {
		$lyearf .= "<option value=\"$year\"".(($year == $yearf)?" selected=\"selected\"":"").">$year</option>";
		$lyeart .= "<option value=\"$year\"".(($year == $yeart)?" selected=\"selected\"":"").">$year</option>";
	}
	for my $month (1 .. 12) {
		$lmonthf .= "<option value=\"$month\"".(($month == $monthf)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
		$lmontht .= "<option value=\"$month\"".(($month == $montht)?" selected=\"selected\"":"").">".$monthtxt[($month - 1)]."</option>";
	}
	for my $day (1 .. 31) {
		$ldayf .= "<option value=\"$day\"".(($day == $dayf)?" selected=\"selected\"":"").">$day</option>";
		$ldayt .= "<option value=\"$day\"".(($day == $dayt)?" selected=\"selected\"":"").">$day</option>";
	}
	my $datef = sprintf("%04d%02d%02d000000", $yearf, $monthf, $dayf);
	my $datet = sprintf("%04d%02d%02d235959", $yeart, $montht, $dayt);

	{
		# electricity stats TDB

		$elused = sprintf("%.1f", $relused);
		$elsaved = sprintf("%.1f", $relsaved);
	}

	my $pagename = $selfpath.$uimode."_".$uismode.".html";
	open(INF,$pagename);
	while (<INF>) {
		my $inline = $_;
		chomp ($inline);
		$inline =~ s/--el_used--/$elused/g;
		$inline =~ s/--el_saved--/$elsaved/g;
		$inline =~ s/--year_f--/$lyearf/g;
		$inline =~ s/--year_t--/$lyeart/g;
		$inline =~ s/--month_f--/$lmonthf/g;
		$inline =~ s/--month_t--/$lmontht/g;
		$inline =~ s/--day_f--/$ldayf/g;
		$inline =~ s/--day_t--/$ldayt/g;
		$inline =~ s/--mode--/$uimode/g;
		$inline =~ s/--submode--/$uismode/g;
		$inline =~ s/--usermode--/$usermode/g;
		$contents .= $inline."\n";
	}
	close(INF);
}

# logout from system

if (($uimode eq "logout") && ($uismode eq "logout") && ($uaccess >= $alevel{$uimode.$uismode})) {
	($password, $uimode, $uismode) = ("", "", "", "");
	$exitstatus = 2;
}

# login page

if (($uimode eq "") && ($uismode eq "")) {
	my $fut_time = gmtime(time() - 3600)." GMT";  # make time expired
	my $cookie = "icsession2014=; path=/; expires=$fut_time;";
	print "Set-Cookie: " . $cookie . "\n";
	$cookie = "usermode2014=; path=/; expires=$fut_time;";
	print "Set-Cookie: " . $cookie . "\n";

	if (-e $loginweb) {
		my $logmsg = "";
		if ($exitstatus == 0) {					# opened by mistake?
		} elsif ($exitstatus == 1) {				# wrong login/password
			$logmsg = "Wrong credentials! Please retry.";
			$cookie = "icuser2014=; path=/; expires=$fut_time;";
			print "Set-Cookie: " . $cookie . "\n";
		} elsif ($exitstatus == 2) {				# logout
			$logmsg = "Good bye.";
		} elsif ($exitstatus == 7) {				# DB error
			$logmsg = "Cannon connect local Database";
		}
		my $savelogin = ($saveduser ne "")?" checked":"";
		$username = ($saveduser ne "")?$saveduser:"";
		print "Content-type: text/html\n\n";
		open(INF,$loginweb);
		while (<INF>) {
			my $inline = $_;
			chomp ($inline);
			$inline =~ s/--logmessage--/$logmsg/g;
			$inline =~ s/--username--/$username/g;
			$inline =~ s/--password--/$password/g;
			$inline =~ s/--savelogin--/$savelogin/g;
			$inline =~ s/--version--/$version/g;
			print $inline."\n";
		}
		close(INF);
	} else {
		print "Content-type: text/html\n\n";
		print "<HEAD>\n";
		print "<META HTTP-EQUIV=REFRESH CONTENT=\"0;URL=$loffweb\">\n";
		print "</HEAD>\n";
	}

	$db->disconnect();
	exit;
}

# print out page

print "Content-type: text/html\n\n";
open(INF,$templateweb);
while (<INF>) {
	my $inline = $_;
	chomp ($inline);
	$inline =~ s/--mainmenu--/$mainmenu/g;
	$inline =~ s/--submenu--/$submenu/g;
	$inline =~ s/--contents--/$contents/g;
	$inline =~ s/--title--/$pagetitle/g;
	$inline =~ s/--version--/$version/g;
	$inline =~ s/--debug--/$debug/g;
	$inline =~ s/--bodyadd--/$bodyadd/g;
	$inline =~ s/--headadd--/$headadd/g;
	print $inline."\n";
}
close(INF);

# exit

$db->disconnect();
exit;

# Quick sync script + submit query

sub dbdo {
	my $query = $_[0];
	my $prio = $_[1] + 0;
	$db->do($query);
#	$db->do("INSERT INTO sync_db VALUES (0, NOW(), $prio, 0, \"$query\")");		# outdated method of replication
	return 1;
}

# nice second representation

sub BreakSec {
	my $seconds = $_[0] + 0;
	my $rsday = floor($seconds / 86400);
	my $rshour = floor($seconds / 3600) - ($rsday * 24);
	my $rsmin = floor($seconds / 60) - ($rsday * 24 * 60) - ($rshour * 60);
	my $brtime = sprintf("%d day %02d hour %02d minute", $rsday, $rshour, $rsmin);
	return $brtime;
}

7;
