#!/bin/sh

/usr/bin/uptime > /tmp/status
/usr/bin/free -m >> /tmp/status
/bin/df >> /tmp/status
/sbin/ifconfig >> /tmp/status
/sbin/route >> /tmp/status
/bin/cat /etc/resolv.conf >> /tmp/status

/var/www/smart/status.pl
/var/www/smart/weather.pl
/var/www/smart/sync_out.pl
/var/www/smart/sync_in.pl
