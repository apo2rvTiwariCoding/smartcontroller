drop database if exists smart2014;
create database smart2014;
grant all on smart2014.* to "smart"@"%" identified by "ase2014";
grant all on smart2014.* to "smart"@"localhost" identified by "ase2014";
flush privileges;
