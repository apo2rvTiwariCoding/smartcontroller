-- MySQL dump 10.13  Distrib 5.5.35, for debian-linux-gnu (armv7l)
--
-- Host: localhost    Database: smart2014
-- ------------------------------------------------------
-- Server version	5.5.35-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarms_networks`
--

DROP TABLE IF EXISTS `alarms_networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_networks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_networks`
--

LOCK TABLES `alarms_networks` WRITE;
/*!40000 ALTER TABLE `alarms_networks` DISABLE KEYS */;
INSERT INTO `alarms_networks` VALUES (1,'2014-05-17 01:42:39','127.0.0.1',1,1,'failed attempt to connect to ISP name server'),(2,'2014-05-17 01:43:41','127.0.0.1',2,2,'consecutive failed attempts to connect to ISP name server'),(3,'2014-05-19 23:28:22','192.168.1.1',1,1,'connect attempt failed');
/*!40000 ALTER TABLE `alarms_networks` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_networks` AFTER INSERT ON `alarms_networks`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_networks'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_networks` AFTER UPDATE ON `alarms_networks`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_networks';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_networks` AFTER DELETE ON `alarms_networks`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_networks';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `alarms_pressure`
--

DROP TABLE IF EXISTS `alarms_pressure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_pressure` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `pressure` int(11) DEFAULT NULL,
  `threshold` int(11) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_pressure`
--

LOCK TABLES `alarms_pressure` WRITE;
/*!40000 ALTER TABLE `alarms_pressure` DISABLE KEYS */;
INSERT INTO `alarms_pressure` VALUES (1,'2014-05-18 00:40:22',100,100,1,1,'blow'),(2,'2014-05-19 23:29:09',110,110,1,1,'bahh');
/*!40000 ALTER TABLE `alarms_pressure` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_pressure` AFTER INSERT ON `alarms_pressure`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_pressure IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_pressure'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_pressure` AFTER UPDATE ON `alarms_pressure`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_pressure IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_pressure';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_pressure` AFTER DELETE ON `alarms_pressure`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_pressure IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_pressure';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `alarms_retrosave`
--

DROP TABLE IF EXISTS `alarms_retrosave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_retrosave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `zone_desc` varchar(100) DEFAULT NULL,
  `device_desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_retrosave`
--

LOCK TABLES `alarms_retrosave` WRITE;
/*!40000 ALTER TABLE `alarms_retrosave` DISABLE KEYS */;
INSERT INTO `alarms_retrosave` VALUES (1,'2014-05-18 00:41:26',2,0,'Kitchen','Louver'),(2,'2014-05-18 00:42:03',8,1,'Room','Wall sensor'),(3,'2014-05-19 23:29:39',2,0,'Hall','Sensor');
/*!40000 ALTER TABLE `alarms_retrosave` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_retrosave` AFTER INSERT ON `alarms_retrosave`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_retrosave IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_retrosave'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_retrosave` AFTER UPDATE ON `alarms_retrosave`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_retrosave IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_retrosave';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_retrosave` AFTER DELETE ON `alarms_retrosave`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_retrosave IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_retrosave';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `alarms_system`
--

DROP TABLE IF EXISTS `alarms_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_system` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_system`
--

LOCK TABLES `alarms_system` WRITE;
/*!40000 ALTER TABLE `alarms_system` DISABLE KEYS */;
INSERT INTO `alarms_system` VALUES (1,'2014-05-17 00:43:59',0,0,'Completed'),(2,'2014-05-18 00:44:14',0,0,'Update completed');
/*!40000 ALTER TABLE `alarms_system` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_system` AFTER INSERT ON `alarms_system`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_system IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_system'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_system` AFTER UPDATE ON `alarms_system`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_system IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_system';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_system` AFTER DELETE ON `alarms_system`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_system IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_system';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `alarms_types`
--

DROP TABLE IF EXISTS `alarms_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `alarm_id` int(11) NOT NULL DEFAULT '0',
  `type_` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `severity` tinyint(4) NOT NULL DEFAULT '0',
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_types`
--

LOCK TABLES `alarms_types` WRITE;
/*!40000 ALTER TABLE `alarms_types` DISABLE KEYS */;
INSERT INTO `alarms_types` VALUES (1,0,0,0,0,'Occupied PIR Trigger'),(2,1,0,1,1,'UNOccupied PIR Trigger'),(3,2,0,1,2,'Battery Status Trigger Value Threshold'),(4,3,0,1,2,'Upper Temperature Value Report Trigger'),(5,4,0,1,2,'Lower Temperature Value Report Trigger'),(6,5,0,1,1,'Upper Humidity Value Report Trigger'),(7,6,0,0,0,'Lower Humidity Value Report Trigger'),(8,7,0,0,0,'LUX Slope Value Report Trigger'),(9,8,0,1,1,'Temperature Slope Value Report Trigger'),(10,9,0,1,2,'Upper CO Value Trigger Report'),(11,10,0,1,2,'Upper CO2 Value Trigger Report'),(12,0,1,0,0,'Zigbee Device Connected to Smart Controller Network'),(13,1,1,1,1,'Loss of Communication with Remote Device'),(14,2,1,1,2,'PAN ID Conflict'),(15,3,1,1,1,'PAN ID Resolution'),(16,4,1,1,0,'RF Interference'),(17,5,1,0,0,'RF Interference Resolution'),(18,0,2,1,0,'System Update Initiated by Admin'),(19,1,2,1,2,'DB Max Storage Level Reached'),(20,0,3,0,0,'Connection Was Successful'),(21,1,3,1,1,'First Failed Attempt to Connect to ISP Name Server'),(22,2,3,1,2,'Consecutive Failed Attempts to Connect to ISP Name Server'),(23,0,4,0,1,'Calculated Static Pressure Below Threshold'),(24,1,4,1,1,'Calculated Static Pressure Exceeded Threshold for the First Time'),(25,2,4,1,1,'Consecutive Calculated Static Pressure Values Exceeded Threshold'),(26,0,5,0,0,'Deletion of a Previously Added Zigbee Device'),(27,1,5,1,1,'Addition of a New Zigbee Device to the Smart Controller DB'),(28,2,5,0,0,'Update the ASEMP Profile of the Remote Device'),(29,3,5,0,0,'Update the Status of the Remote Device'),(30,4,5,0,0,'Update the Zigbee Short Address of the Remote Device'),(31,-1,0,0,0,'RetroSAVE Alarms'),(32,-1,1,0,0,'Zigbee Alarms'),(33,-1,2,0,0,'System Alarms'),(34,-1,3,0,0,'IP Network Alarms'),(35,-1,4,0,0,'Pressure Alarms'),(36,-1,5,0,0,'Registration Events');
/*!40000 ALTER TABLE `alarms_types` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_types` AFTER INSERT ON `alarms_types`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_types IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_types'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_types` AFTER UPDATE ON `alarms_types`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_types IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_types';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_types` AFTER DELETE ON `alarms_types`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_types IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_types';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `alarms_zigbee`
--

DROP TABLE IF EXISTS `alarms_zigbee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarms_zigbee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `panid` int(11) DEFAULT NULL,
  `addr64` varchar(32) DEFAULT NULL,
  `address` int(11) DEFAULT NULL,
  `rssi` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms_zigbee`
--

LOCK TABLES `alarms_zigbee` WRITE;
/*!40000 ALTER TABLE `alarms_zigbee` DISABLE KEYS */;
INSERT INTO `alarms_zigbee` VALUES (1,1,1,'2014-05-18 00:45:02',1111,'1111',1111,11,11,1,1,'signal loss'),(2,2,2,'2014-05-18 00:45:33',2222,'2222',2222,22,1,4,2,'interferecence'),(3,3,3,'2014-05-18 00:46:16',3333,'3333',3333,3,3,5,1,'all ok'),(4,1,1,'2014-05-19 23:25:50',1111,'111',111,11,11,1,0,'signal loss'),(5,2,2,'2014-05-19 23:26:15',1111,'111',111,11,11,1,0,'signal loss');
/*!40000 ALTER TABLE `alarms_zigbee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_alarms_zigbee` AFTER INSERT ON `alarms_zigbee`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_alarms_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_zigbee'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_alarms_zigbee` AFTER UPDATE ON `alarms_zigbee`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_zigbee';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_alarms_zigbee` AFTER DELETE ON `alarms_zigbee`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_alarms_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'alarms_zigbee';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `asemp`
--

DROP TABLE IF EXISTS `asemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asemp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `parameter` varchar(50) NOT NULL,
  `value` int(11) DEFAULT NULL,
  `default_` int(11) NOT NULL DEFAULT '0',
  `description` varchar(200) DEFAULT NULL,
  `type_` tinyint(4) NOT NULL DEFAULT '0',
  `units` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=569 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asemp`
--

LOCK TABLES `asemp` WRITE;
/*!40000 ALTER TABLE `asemp` DISABLE KEYS */;
INSERT INTO `asemp` VALUES (1,0,'occu_pir',0,0,'Occupied PIR Trigger Enable',0,NULL),(2,0,'unoccu_pir',1,1,'Unoccupied PIR Trigger Enable',0,NULL),(3,0,'occu_rep',120,120,'Occupied Reporting Period',1,'seconds'),(4,0,'unoccu_rep',360,360,'Unoccupied Reporting Period\r\n',1,'seconds'),(5,0,'min_rep_int',60,60,'Minimum Time Interval Between Consecutive Unsolicited Reports',1,'seconds'),(6,0,'bat_stat_thr',10,10,'Battery Status Trigger Value Threshold',1,NULL),(7,0,'temp_sl_tr',0,0,'Temperature Slope Value Report Trigger',1,'degree C'),(8,0,'up_temp_tr',35,35,'Upper Temperature Value Report Trigger\r\n',1,'degree C'),(9,0,'lo_temp_tr',5,5,'Lower Temperature Value Report Trigger\r\n',1,'degree C'),(10,0,'up_hum_tr',60,60,'Upper Humidity Value Report Trigger',1,'% RH'),(11,0,'lo_hum_tr',30,30,'Lower Humidity Value Report Trigger',1,'% RH'),(12,0,'lux_sl_tr',0,0,'LUX Slope Value Report Trigger',1,'lux'),(13,0,'max_retry',3,3,'ASEMP Max Retry Count',1,NULL),(14,0,'max_wait',60,60,'ASEMP MAX Wait Timer',1,'seconds'),(15,0,'up_co_tr',0,0,'Upper CO Value Trigger Report',1,'ppm'),(16,0,'up_co2_tr',1000,1000,'Upper CO2 Value Trigger Report\r\n',1,'ppm'),(17,0,'aud_alarm',1,1,'Audible Alarm Enable',0,NULL),(18,0,'led_alarm',1,1,'LED Alarm Enable',0,NULL),(19,0,'name',0,0,'Default ASEMP Profile',2,NULL),(474,4,'aud_alarm',1,1,'aud_alarm',0,''),(475,4,'bat_stat_thr',10,10,'bat_stat_thr',0,''),(476,4,'led_alarm',1,1,'led_alarm',0,''),(477,4,'lo_hum_tr',30,30,'lo_hum_tr',0,''),(478,4,'lo_temp_tr',5,5,'lo_temp_tr',0,''),(479,4,'lux_sl_tr',1,1,'lux_sl_tr',0,''),(480,4,'max_retry',3,3,'max_retry',0,''),(481,4,'max_wait',60,60,'max_wait',0,''),(482,4,'min_rep_int',60,60,'min_rep_int',0,''),(483,4,'occu_pir',0,0,'occu_pir',0,''),(484,4,'occu_rep',120,120,'occu_rep',0,''),(485,4,'temp_sl_tr',0,0,'temp_sl_tr',0,''),(486,4,'unoccu_pir',1,1,'unoccu_pir',0,''),(487,4,'unoccu_rep',360,360,'unoccu_rep',0,''),(488,4,'up_co2_tr',1000,1000,'up_co2_tr',0,''),(489,4,'up_co_tr',0,0,'up_co_tr',0,''),(490,4,'up_hum_tr',60,60,'up_hum_tr',0,''),(491,4,'up_temp_tr',35,35,'up_temp_tr',0,''),(492,4,'name',0,0,'User Defined ASEMP Profile 4',2,''),(531,3,'aud_alarm',0,0,'aud_alarm',0,''),(532,3,'bat_stat_thr',13,13,'bat_stat_thr',0,''),(533,3,'led_alarm',0,0,'led_alarm',0,''),(534,3,'lo_hum_tr',13,13,'lo_hum_tr',0,''),(535,3,'lo_temp_tr',13,13,'lo_temp_tr',0,''),(536,3,'lux_sl_tr',13,13,'lux_sl_tr',0,''),(537,3,'max_retry',13,13,'max_retry',0,''),(538,3,'max_wait',13,13,'max_wait',0,''),(539,3,'min_rep_int',13,13,'min_rep_int',0,''),(540,3,'occu_pir',1,1,'occu_pir',0,''),(541,3,'occu_rep',11,11,'occu_rep',0,''),(542,3,'temp_sl_tr',13,13,'temp_sl_tr',0,''),(543,3,'unoccu_pir',1,1,'unoccu_pir',0,''),(544,3,'unoccu_rep',11,11,'unoccu_rep',0,''),(545,3,'up_co2_tr',13,13,'up_co2_tr',0,''),(546,3,'up_co_tr',13,13,'up_co_tr',0,''),(547,3,'up_hum_tr',13,13,'up_hum_tr',0,''),(548,3,'up_temp_tr',13,13,'up_temp_tr',0,''),(549,3,'name',0,0,'User Defined ASEMP Profile 3',2,''),(550,2,'aud_alarm',1,1,'aud_alarm',0,''),(551,2,'bat_stat_thr',10,10,'bat_stat_thr',0,''),(552,2,'led_alarm',1,1,'led_alarm',0,''),(553,2,'lo_hum_tr',30,30,'lo_hum_tr',0,''),(554,2,'lo_temp_tr',5,5,'lo_temp_tr',0,''),(555,2,'lux_sl_tr',0,0,'lux_sl_tr',0,''),(556,2,'max_retry',3,3,'max_retry',0,''),(557,2,'max_wait',60,60,'max_wait',0,''),(558,2,'min_rep_int',60,60,'min_rep_int',0,''),(559,2,'occu_pir',0,0,'occu_pir',0,''),(560,2,'occu_rep',122,122,'occu_rep',0,''),(561,2,'temp_sl_tr',0,0,'temp_sl_tr',0,''),(562,2,'unoccu_pir',1,1,'unoccu_pir',0,''),(563,2,'unoccu_rep',360,360,'unoccu_rep',0,''),(564,2,'up_co2_tr',1000,1000,'up_co2_tr',0,''),(565,2,'up_co_tr',0,0,'up_co_tr',0,''),(566,2,'up_hum_tr',60,60,'up_hum_tr',0,''),(567,2,'up_temp_tr',35,35,'up_temp_tr',0,''),(568,2,'name',0,0,'User Defined ASEMP Profile 2',2,'');
/*!40000 ALTER TABLE `asemp` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_asemp` AFTER INSERT ON `asemp`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_asemp IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'asemp'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_asemp` AFTER UPDATE ON `asemp`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_asemp IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'asemp';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_asemp` AFTER DELETE ON `asemp`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_asemp IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'asemp';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `bypass`
--

DROP TABLE IF EXISTS `bypass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bypass` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `type_` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bypass`
--

LOCK TABLES `bypass` WRITE;
/*!40000 ALTER TABLE `bypass` DISABLE KEYS */;
INSERT INTO `bypass` VALUES (1,'2014-04-06 01:01:01',0,0,'test switch toggle'),(2,'2014-04-06 02:02:02',1,0,'test switch toggle 2'),(3,'2014-05-16 20:35:22',2,1,'Toggle from mobile app'),(4,'2014-05-16 20:35:23',2,0,'Toggle from mobile app'),(5,'2014-05-16 20:35:44',2,1,'Toggle from mobile app'),(6,'2014-05-16 20:41:14',2,0,'Toggle from mobile app'),(7,'2014-05-16 20:41:17',2,1,'Toggle from mobile app'),(8,'2014-05-16 20:41:18',2,0,'Toggle from mobile app'),(9,'2014-05-16 20:41:20',2,1,'Toggle from mobile app'),(10,'2014-05-16 20:41:22',2,0,'Toggle from mobile app'),(11,'2014-05-19 13:07:26',2,1,'Toggle from mobile app'),(12,'2014-05-19 13:07:28',2,0,'Toggle from mobile app'),(13,'2014-05-19 13:10:07',2,1,'Toggle from mobile app'),(14,'2014-05-19 13:10:28',2,0,'Toggle from mobile app'),(15,'2014-05-20 12:51:30',2,1,'Toggle from mobile app'),(16,'2014-05-20 12:51:54',2,0,'Toggle from mobile app'),(17,'2014-05-22 05:50:32',2,1,'Toggle from mobile app'),(18,'2014-05-22 05:50:32',2,0,'Toggle from mobile app');
/*!40000 ALTER TABLE `bypass` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_bypass` AFTER INSERT ON `bypass`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_bypass IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'bypass'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_bypass` AFTER UPDATE ON `bypass`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_bypass IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'bypass';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_bypass` AFTER DELETE ON `bypass`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_bypass IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'bypass';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `deviceadvanced`
--

DROP TABLE IF EXISTS `deviceadvanced`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deviceadvanced` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `type_` int(11) NOT NULL,
  `realvar1` double NOT NULL,
  `realvar2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deviceadvanced`
--

LOCK TABLES `deviceadvanced` WRITE;
/*!40000 ALTER TABLE `deviceadvanced` DISABLE KEYS */;
INSERT INTO `deviceadvanced` VALUES (6,13,3,1,0),(5,13,2,1.2,0.2),(4,13,1,1.1,0.1);
/*!40000 ALTER TABLE `deviceadvanced` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_deviceadvanced` AFTER INSERT ON `deviceadvanced`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_deviceadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'deviceadvanced'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_deviceadvanced` AFTER UPDATE ON `deviceadvanced`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_deviceadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'deviceadvanced';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_deviceadvanced` AFTER DELETE ON `deviceadvanced`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_deviceadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'deviceadvanced';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL DEFAULT '1',
  `hardware_type` int(11) NOT NULL DEFAULT '0',
  `device_type` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `xbee_addr64` varchar(31) DEFAULT NULL,
  `asemp` int(11) NOT NULL DEFAULT '1',
  `serial` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zone_id` (`zone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (16,5,0,1,'Hall main sensor','1122334455667788',2,NULL),(17,5,0,2,'Hall louver','1122334455667789',0,NULL),(18,3,0,1,'Kitchen sensor','1122334455667780',0,NULL),(19,3,0,2,'Kitchen louver','1212121212121212',0,NULL),(20,4,0,1,'Room sensor','4543545454545455',0,NULL),(21,4,0,2,'Room louver','4535654646565654',0,NULL),(22,6,0,0,'Outdoor sensor','3059384058359089',0,NULL),(23,2,0,1,'ASE Indoor Sensor','1122334455667788',0,NULL),(24,5,0,2,'Louver Complete','1122334455667799',0,'');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_devices` AFTER INSERT ON `devices`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_devices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devices'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_devices` AFTER UPDATE ON `devices`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_devices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devices';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_devices` AFTER DELETE ON `devices`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_devices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devices';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `devicesdyn`
--

DROP TABLE IF EXISTS `devicesdyn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicesdyn` (
  `device_id` int(11) NOT NULL,
  `online` tinyint(1) DEFAULT NULL,
  `device_status` int(11) DEFAULT NULL,
  `updated_time` datetime DEFAULT NULL,
  `battery_charge` int(11) DEFAULT NULL,
  `remote_ack` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devicesdyn`
--

LOCK TABLES `devicesdyn` WRITE;
/*!40000 ALTER TABLE `devicesdyn` DISABLE KEYS */;
INSERT INTO `devicesdyn` VALUES (16,1,NULL,NULL,NULL,1),(17,1,NULL,NULL,NULL,1),(22,1,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `devicesdyn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_devicesdyn` AFTER INSERT ON `devicesdyn`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_devicesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devicesdyn'; 						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_devicesdyn` AFTER UPDATE ON `devicesdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_devicesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devicesdyn';						SET @pk_d_old = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_devicesdyn` AFTER DELETE ON `devicesdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_devicesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'devicesdyn';						SET @pk_d = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_` int(11) unsigned NOT NULL,
  `stages` int(11) unsigned NOT NULL,
  `maker` varchar(100) NOT NULL,
  `model` varchar(200) NOT NULL,
  `max_on` int(11) NOT NULL DEFAULT '0',
  `min_on` int(11) NOT NULL DEFAULT '0',
  `min_off` int(11) NOT NULL DEFAULT '0',
  `out_temp_cut` int(11) DEFAULT NULL,
  `cots_type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_equipment` AFTER INSERT ON `equipment`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_equipment IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'equipment'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_equipment` AFTER UPDATE ON `equipment`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_equipment IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'equipment';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_equipment` AFTER DELETE ON `equipment`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_equipment IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'equipment';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `started` datetime NOT NULL,
  `ended` datetime DEFAULT NULL,
  `severity` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2860 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'2012-12-26 03:27:34',NULL,0,0,'Database init finished'),(2,'2012-12-28 03:46:18',NULL,3,2,'Dangerous CO2 (carbon dioxide) Level 6 ppm'),(0,'2013-01-10 19:17:31',NULL,3,2,'Dangerous CO (carbon monoxide) Level 2.000 ppm!'),(63,'2013-01-11 00:05:44',NULL,3,0,'Dangerous CO2 (carbon dioxide) Level 1007.000 ppm!'),(64,'2013-01-11 00:05:45',NULL,3,0,'Dangerous CO (carbon monoxide) Level 6.000 ppm!'),(65,'2013-01-11 00:08:14',NULL,3,2,'Dangerous CO2 (carbon dioxide) Level 1007.000 ppm!'),(66,'2013-01-11 00:08:14',NULL,3,2,'Dangerous CO (carbon monoxide) Level 6.000 ppm!'),(67,'2013-03-07 00:00:00',NULL,0,0,'UI version updated'),(68,'2013-03-11 17:00:00',NULL,0,2,'UI version updated'),(69,'2013-08-01 01:01:01',NULL,1,0,'Notification about something'),(70,'2013-08-01 01:02:03',NULL,2,0,'Low priority alarm about something'),(71,'2013-08-01 03:02:01',NULL,3,2,'Emergency! do something'),(72,'2013-09-23 01:01:01',NULL,3,2,'Test emergency event'),(73,'2013-09-23 02:02:02',NULL,3,0,'Another test emergency event'),(74,'2013-09-23 21:05:00',NULL,1,0,'Notification about new beta version to release'),(75,'2013-09-26 14:30:00',NULL,2,0,'Main page finished and tested'),(76,'2013-09-26 15:00:00',NULL,1,0,'lunch time!'),(77,'2013-11-29 17:47:50',NULL,1,0,'New simulation started'),(78,'2013-11-29 18:25:08',NULL,1,0,'New simulation started'),(79,'2013-11-29 18:26:10',NULL,1,0,'New simulation started'),(80,'2013-11-29 18:27:11',NULL,1,0,'New simulation started'),(81,'2013-11-29 18:28:12',NULL,1,0,'New simulation started'),(82,'2013-11-29 18:29:14',NULL,1,0,'New simulation started'),(83,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(84,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(85,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(86,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(87,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(88,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(89,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(90,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(91,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(92,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(93,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(94,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(95,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(96,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(97,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(98,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(99,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(100,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(101,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(102,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(103,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(104,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(105,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(106,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(107,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(108,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(109,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(110,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(111,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(112,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(113,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(114,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(115,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(116,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(117,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(118,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(119,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(120,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(121,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(122,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(123,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(124,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(125,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(126,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(127,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(128,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(129,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(130,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(131,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(132,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(133,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(134,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(135,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(136,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(137,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(138,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(139,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(140,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(141,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(142,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(143,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(144,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(145,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(146,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(147,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(148,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(149,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(150,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(151,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(152,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(153,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(154,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(155,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(156,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(157,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(158,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(159,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(160,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(161,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(162,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(163,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(164,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(165,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(166,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(167,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(168,'2014-07-02 23:38:13','2014-07-02 23:38:13',0,0,'deadloop'),(169,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(170,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(171,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(172,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(173,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(174,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(175,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(176,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(177,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(178,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(179,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(180,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(181,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(182,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(183,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(184,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(185,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(186,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(187,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(188,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(189,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(190,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(191,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(192,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(193,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(194,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(195,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(196,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(197,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(198,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(199,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(200,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(201,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(202,'2014-07-02 23:38:14','2014-07-02 23:38:14',0,0,'deadloop'),(203,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(204,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(205,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(206,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(207,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(208,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(209,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(210,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(211,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(212,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(213,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(214,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(215,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(216,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(217,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(218,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(219,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(220,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(221,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(222,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(223,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(224,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(225,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(226,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(227,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(228,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(229,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(230,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(231,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(232,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(233,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(234,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(235,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(236,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(237,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(238,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(239,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(240,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(241,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(242,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(243,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(244,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(245,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(246,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(247,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(248,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(249,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(250,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(251,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(252,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(253,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(254,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(255,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(256,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(257,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(258,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(259,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(260,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(261,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(262,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(263,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(264,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(265,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(266,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(267,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(268,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(269,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(270,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(271,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(272,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(273,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(274,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(275,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(276,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(277,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(278,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(279,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(280,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(281,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(282,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(283,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(284,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(285,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(286,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(287,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(288,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(289,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(290,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(291,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(292,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(293,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(294,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(295,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(296,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(297,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(298,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(299,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(300,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(301,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(302,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(303,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(304,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(305,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(306,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(307,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(308,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(309,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(310,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(311,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(312,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(313,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(314,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(315,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(316,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(317,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(318,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(319,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(320,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(321,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(322,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(323,'2014-07-02 23:38:15','2014-07-02 23:38:15',0,0,'deadloop'),(324,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(325,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(326,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(327,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(328,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(329,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(330,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(331,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(332,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(333,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(334,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(335,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(336,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(337,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(338,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(339,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(340,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(341,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(342,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(343,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(344,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(345,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(346,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(347,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(348,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(349,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(350,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(351,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(352,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(353,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(354,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(355,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(356,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(357,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(358,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(359,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(360,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(361,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(362,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(363,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(364,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(365,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(366,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(367,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(368,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(369,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(370,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(371,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(372,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(373,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(374,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(375,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(376,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(377,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(378,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(379,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(380,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(381,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(382,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(383,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(384,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(385,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(386,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(387,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(388,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(389,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(390,'2014-07-02 23:38:16','2014-07-02 23:38:16',0,0,'deadloop'),(391,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(392,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(393,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(394,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(395,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(396,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(397,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(398,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(399,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(400,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(401,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(402,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(403,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(404,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(405,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(406,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(407,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(408,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(409,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(410,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(411,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(412,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(413,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(414,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(415,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(416,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(417,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(418,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(419,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(420,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(421,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(422,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(423,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(424,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(425,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(426,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(427,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(428,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(429,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(430,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(431,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(432,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(433,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(434,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(435,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(436,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(437,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(438,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(439,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(440,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(441,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(442,'2014-07-02 23:38:17','2014-07-02 23:38:17',0,0,'deadloop'),(443,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(444,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(445,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(446,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(447,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(448,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(449,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(450,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(451,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(452,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(453,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(454,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(455,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(456,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(457,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(458,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(459,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(460,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(461,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(462,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(463,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(464,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(465,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(466,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(467,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(468,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(469,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(470,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(471,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(472,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(473,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(474,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(475,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(476,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(477,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(478,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(479,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(480,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(481,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(482,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(483,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(484,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(485,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(486,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(487,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(488,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(489,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(490,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(491,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(492,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(493,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(494,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(495,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(496,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(497,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(498,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(499,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(500,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(501,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(502,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(503,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(504,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(505,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(506,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(507,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(508,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(509,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(510,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(511,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(512,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(513,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(514,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(515,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(516,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(517,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(518,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(519,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(520,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(521,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(522,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(523,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(524,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(525,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(526,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(527,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(528,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(529,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(530,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(531,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(532,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(533,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(534,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(535,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(536,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(537,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(538,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(539,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(540,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(541,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(542,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(543,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(544,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(545,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(546,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(547,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(548,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(549,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(550,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(551,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(552,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(553,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(554,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(555,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(556,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(557,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(558,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(559,'2014-07-02 23:38:18','2014-07-02 23:38:18',0,0,'deadloop'),(560,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(561,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(562,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(563,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(564,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(565,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(566,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(567,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(568,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(569,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(570,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(571,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(572,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(573,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(574,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(575,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(576,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(577,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(578,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(579,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(580,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(581,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(582,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(583,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(584,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(585,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(586,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(587,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(588,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(589,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(590,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(591,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(592,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(593,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(594,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(595,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(596,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(597,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(598,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(599,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(600,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(601,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(602,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(603,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(604,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(605,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(606,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(607,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(608,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(609,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(610,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(611,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(612,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(613,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(614,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(615,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(616,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(617,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(618,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(619,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(620,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(621,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(622,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(623,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(624,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(625,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(626,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(627,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(628,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(629,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(630,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(631,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(632,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(633,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(634,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(635,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(636,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(637,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(638,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(639,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(640,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(641,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(642,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(643,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(644,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(645,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(646,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(647,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(648,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(649,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(650,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(651,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(652,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(653,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(654,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(655,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(656,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(657,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(658,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(659,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(660,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(661,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(662,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(663,'2014-07-02 23:38:19','2014-07-02 23:38:19',0,0,'deadloop'),(664,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(665,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(666,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(667,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(668,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(669,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(670,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(671,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(672,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(673,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(674,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(675,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(676,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(677,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(678,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(679,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(680,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(681,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(682,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(683,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(684,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(685,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(686,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(687,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(688,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(689,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(690,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(691,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(692,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(693,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(694,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(695,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(696,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(697,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(698,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(699,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(700,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(701,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(702,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(703,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(704,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(705,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(706,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(707,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(708,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(709,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(710,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(711,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(712,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(713,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(714,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(715,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(716,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(717,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(718,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(719,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(720,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(721,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(722,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(723,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(724,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(725,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(726,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(727,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(728,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(729,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(730,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(731,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(732,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(733,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(734,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(735,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(736,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(737,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(738,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(739,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(740,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(741,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(742,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(743,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(744,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(745,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(746,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(747,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(748,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(749,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(750,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(751,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(752,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(753,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(754,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(755,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(756,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(757,'2014-07-02 23:38:20','2014-07-02 23:38:20',0,0,'deadloop'),(758,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(759,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(760,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(761,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(762,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(763,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(764,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(765,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(766,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(767,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(768,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(769,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(770,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(771,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(772,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(773,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(774,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(775,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(776,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(777,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(778,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(779,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(780,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(781,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(782,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(783,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(784,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(785,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(786,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(787,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(788,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(789,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(790,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(791,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(792,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(793,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(794,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(795,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(796,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(797,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(798,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(799,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(800,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(801,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(802,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(803,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(804,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(805,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(806,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(807,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(808,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(809,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(810,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(811,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(812,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(813,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(814,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(815,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(816,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(817,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(818,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(819,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(820,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(821,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(822,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(823,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(824,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(825,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(826,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(827,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(828,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(829,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(830,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(831,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(832,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(833,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(834,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(835,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(836,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(837,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(838,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(839,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(840,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(841,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(842,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(843,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(844,'2014-07-02 23:38:21','2014-07-02 23:38:21',0,0,'deadloop'),(845,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(846,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(847,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(848,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(849,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(850,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(851,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(852,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(853,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(854,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(855,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(856,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(857,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(858,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(859,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(860,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(861,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(862,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(863,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(864,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(865,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(866,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(867,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(868,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(869,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(870,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(871,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(872,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(873,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(874,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(875,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(876,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(877,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(878,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(879,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(880,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(881,'2014-07-02 23:38:22','2014-07-02 23:38:22',0,0,'deadloop'),(2859,'2014-07-02 23:52:02','2014-07-02 23:52:02',0,0,'deadloop 2');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_events` AFTER INSERT ON `events`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_events IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'events'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_events` AFTER UPDATE ON `events`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_events IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'events';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_events` AFTER DELETE ON `events`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_events IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'events';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `history_store`
--

DROP TABLE IF EXISTS `history_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history_store` (
  `timemark` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `table_name` tinytext NOT NULL,
  `pk_date_src` text NOT NULL,
  `pk_date_dest` text NOT NULL,
  `record_state` int(11) NOT NULL,
  PRIMARY KEY (`table_name`(100),`pk_date_dest`(100))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_store`
--

LOCK TABLES `history_store` WRITE;
/*!40000 ALTER TABLE `history_store` DISABLE KEYS */;
INSERT INTO `history_store` VALUES ('2014-07-18 20:54:23','smartstatus','<id>8</id>','<id>8</id>',2);
/*!40000 ALTER TABLE `history_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_store_old`
--

DROP TABLE IF EXISTS `history_store_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history_store_old` (
  `timemark` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `table_name` tinytext,
  `pk_date_src` text NOT NULL,
  `pk_date_dest` text,
  `record_state` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_store_old`
--

LOCK TABLES `history_store_old` WRITE;
/*!40000 ALTER TABLE `history_store_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_store_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hvac`
--

DROP TABLE IF EXISTS `hvac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hvac` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `submenu` int(11) NOT NULL DEFAULT '0',
  `value_` varchar(100) DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `selections` varchar(200) DEFAULT NULL,
  `dependence` varchar(200) DEFAULT NULL,
  `permissions` int(11) unsigned NOT NULL DEFAULT '0',
  `units` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `option_` (`option_`),
  UNIQUE KEY `option__2` (`option_`)
) ENGINE=MyISAM AUTO_INCREMENT=2229 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hvac`
--

LOCK TABLES `hvac` WRITE;
/*!40000 ALTER TABLE `hvac` DISABLE KEYS */;
INSERT INTO `hvac` VALUES (77,'furnace','Furnace',0,NULL,NULL,NULL,NULL,1,NULL),(79,'furnace.stages','Stages',77,'0',3,'0::Single Stage;;1::Dual Stage;;2::Modulating',NULL,1,NULL),(80,'furnace.dataport','Data Access Port',77,'NONE',1,'10',NULL,1,NULL),(81,'furnace.port_speed','Data Access Port Speed',77,'9600',1,'10',NULL,1,NULL),(82,'furnace.hc_trans','Heat/Cool Transformer Setup',77,'0',3,'0::Same;;1::Different',NULL,1,'bps'),(93,'furnace.model','Furnace Model',77,'',1,'25',NULL,1,NULL),(84,'furnace.bridge_rcrh','Bridge Rc Rh',77,'0',3,'0::No;;1::Yes',NULL,1,NULL),(85,'furnace.cent_hum','Central Humidifier Control',77,'0',3,'0::Disabled;;1::Enabled',NULL,1,NULL),(86,'furnace.max_on','Maximum ON Time',77,'3600',1,'5',NULL,1,'seconds'),(1194,'furnace.sup_t_probes','Supply Duct Temperature Probes Installed',77,'1',3,'0::No;;1::Yes',NULL,1,NULL),(1195,'furnace.t1_up','Supply Duct Temperature Threshold Upper Limit',77,'28',1,'5',NULL,1,'&deg;C'),(1196,'furnace.t1_low','Supply Duct Temperature Threshold Lower Limit',77,'16',1,'5',NULL,1,'&deg;C'),(1197,'furnace.t2_up','Return Duct Temperature Threshold Upper Limit',77,'26',1,'5',NULL,1,'&deg;C'),(1198,'furnace.t2_low','Return Duct Temperature Threshold Lower Limit',77,'16',1,'5',NULL,1,'&deg;C'),(1199,'furnace.sensor_poll','Smart Controller Onboard Sensors Polling Period',77,'60',1,'5',NULL,1,'seconds'),(1200,'furnace.mode','Operating Mode',77,'0',3,'0::Bypass;;1::RetroSAVE',NULL,1,NULL),(94,'fblower','Furnace Blower',0,NULL,NULL,NULL,NULL,1,NULL),(95,'fblower.min_on','Minimum ON Time',94,'120',1,'5',NULL,1,'seconds'),(96,'fblower.min_off','Minimum OFF Time',94,'60',1,'5',NULL,1,'seconds'),(97,'fblower.max_on','Maximum ON Time',94,'0',1,'5',NULL,1,'seconds'),(98,'fblower.heat_cycle','Heat Cycle Timer',94,'120',1,'5',NULL,1,'seconds'),(99,'fblower.cool_cycle','Cooling Cycle Timer',94,'360',1,'5',NULL,1,'seconds'),(100,'fblower.stat_pres','Static Pressure Threshold',94,'0',1,'5',NULL,1,'kpa'),(74,'system','System Settings',0,NULL,NULL,NULL,NULL,3,NULL),(75,'system.notifications_sms','Enable notifications by SMS',74,'1',1,NULL,NULL,3,NULL),(76,'system.notifications_email','Enable notifications by EMail',74,'1',1,NULL,NULL,3,NULL),(117,'thermostat','Customer Thermostat',0,NULL,NULL,NULL,NULL,1,NULL),(101,'acheat','A/C & Heat Pump',0,NULL,NULL,NULL,NULL,1,NULL),(102,'acheat.installed','Pump Installed',101,'0',3,'0::No;;1::Yes',NULL,1,NULL),(103,'acheat.stages','Stages',101,'0',3,'0::Single Stage;;1::Dual Stage',NULL,1,NULL),(104,'acheat.min_comp_on','Minimum Compressor ON Time',101,'0',1,'5',NULL,1,'seconds'),(105,'acheat.min_comp_off','Minimum Compressor OFF Time',101,'0',1,'5',NULL,1,'seconds'),(106,'acheat.max_comp_on','Maximum Compressor ON Time',101,'0',1,'5',NULL,1,'seconds'),(107,'acheat.out_temp_cut','Outside Temperature Cutoff',101,'-5',1,'5',NULL,1,'&deg;C'),(108,'acheat.ob_heat','O/B Heat Call',101,'0',3,'0::Floating (off);;1::Set to R (on)',NULL,1,NULL),(109,'hrverv','HRV/ERV Control',0,NULL,NULL,NULL,NULL,1,NULL),(110,'hrverv.installed','Installed',109,'0',3,'0::No;;1::Yes',NULL,1,NULL),(111,'hrverv.relay_id','Relay ID',109,'6',3,'1::Relay #1;;2::Relay #2;;3::Relay #3;;4::Relay #4;;5::Relay #5;;6::Relay #6',NULL,1,NULL),(112,'hrverv.sync','Synchronized With Furnace Blower',109,'0',3,'0::No;;1::Yes',NULL,1,NULL),(113,'hrverv.min_on','Minimum ON Time',109,'120',1,'5',NULL,1,'seconds'),(114,'hrverv.min_off','Minimum OFF Time',109,'60',1,'5',NULL,1,'seconds'),(115,'hrverv.max_on','Maximum ON Time',109,'0',1,'5',NULL,1,'seconds'),(116,'comfort','Comfort Level',0,NULL,NULL,NULL,NULL,1,NULL),(118,'thermostat.connected','COTS Connected',117,'1',3,'0::No;;1::Yes',NULL,1,NULL),(120,'system.regmode','New Remote Devices Registration Mode',74,'1',3,'0::Disabled;;1::AdHoc;;2::Manual',NULL,3,NULL),(119,'thermostat.type','Thermostat Type',117,'0',3,'0::Analog;;1::Smart',NULL,1,NULL),(1179,'thermostat.maker','Thermostat Maker',117,'Honeywell',1,'20',NULL,1,NULL),(1180,'thermostat.model','Thermostat Model',117,'Prestige HD',1,'20',NULL,1,NULL),(1,'system.serial','Smart Controller Serial Number',74,'ASESMART-00001',1,'20',NULL,3,NULL),(2,'system.house_id','Unique House ID',74,'00001',1,'5',NULL,3,NULL),(1181,'comfort.min_hum','Humidity Minimum Acceptable Level',116,'30',1,'5',NULL,1,'%'),(1182,'comfort.max_hum','Humidity Maximum Acceptable Level',116,'60',1,'5',NULL,1,'%'),(1183,'comfort.t_occ_win','Default Winter Occupied Temperature',116,'21',1,'5',NULL,1,'&deg;C'),(1184,'comfort.t_occ_sum','Default Summer Occupied Temperature',116,'24',1,'5',NULL,1,'&deg;C'),(1185,'comfort.slider_def','Default Slider Settings',116,'0',3,'0::Max Comfort;;2::Balanced;;4::Max Saving',NULL,1,NULL),(1186,'comfort.co2_up','CO2 Upper Limit',116,'1000',1,'5',NULL,1,'ppm'),(1187,'comfort.co_up','CO Upper Limit',116,'5',1,'5',NULL,1,'ppm'),(1188,'comfort.circ_on','Circulation Cycle ON Time',116,'300',1,'5',NULL,1,'seconds'),(1189,'comfort.circ_off','Circulation Cycle OFF Time',116,'25',1,'5',NULL,1,'minutes'),(4,'system.sw_version','System Software Version',74,'14.5.20p',1,'10',NULL,3,NULL),(1191,'system.max_days','Keep Statistics Data in DB for days',74,'14',1,'5',NULL,3,NULL),(1192,'system.max_storage','Maximum Storage Count Reach Actions',74,'0',3,'0::Delete oldest records;;1::Stop collecting stats',NULL,3,NULL),(3,'system.description','System Short Description',74,'Dmitry local Raspberry',1,'50',NULL,3,NULL),(1193,'furnace.ret_t_probes','Return Duct Temperature Probes Installed',77,'0',3,'0::No;;1::Yes',NULL,1,NULL),(2223,'retrosave','RetroSAVE Operational Parameters',0,NULL,NULL,NULL,NULL,3,NULL),(2224,'retrosave.away_mode','Away mode',2223,'0',4,'0::Disabled;;1::Enabled',NULL,3,NULL),(2225,'retrosave.away_period','Set Away mode after period',2223,'24',1,'5',NULL,3,'hours'),(1178,'thermostat.mode','Thermostat Mode',117,'1',3,'0::Cold only;;1::Auto mode;;2::Heat only',NULL,1,NULL),(2227,'retrosave.comfort_t','Comfort temperature adjustment',2223,'1',1,'3',NULL,3,NULL),(2228,'retrosave.comfort_h','Comfort humidity adjustment',2223,'-1',1,'3',NULL,3,NULL);
/*!40000 ALTER TABLE `hvac` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_hvac` AFTER INSERT ON `hvac`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_hvac IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'hvac'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_hvac` AFTER UPDATE ON `hvac`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_hvac IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'hvac';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_hvac` AFTER DELETE ON `hvac`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_hvac IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'hvac';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `networks`
--

DROP TABLE IF EXISTS `networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dns1` varchar(20) NOT NULL,
  `dns2` varchar(20) DEFAULT NULL,
  `cloud1` varchar(20) NOT NULL,
  `cloud2` varchar(20) DEFAULT NULL,
  `ap_name` varchar(50) NOT NULL,
  `ap_channel` tinyint(4) NOT NULL DEFAULT '6',
  `ap_security` varchar(10) NOT NULL,
  `ap_protocol` int(11) DEFAULT '0',
  `lan_dhcp` tinyint(4) NOT NULL DEFAULT '1',
  `lan_ip` varchar(20) DEFAULT NULL,
  `lan_gateway` varchar(20) DEFAULT NULL,
  `lan_netmask` varchar(20) DEFAULT NULL,
  `lan_dns` varchar(20) DEFAULT NULL,
  `wan_ap_name` varchar(50) DEFAULT NULL,
  `wan_ap_key` varchar(50) DEFAULT NULL,
  `timeserver1` varchar(20) NOT NULL,
  `timeserver2` varchar(20) DEFAULT NULL,
  `cell_modem` tinyint(4) NOT NULL DEFAULT '0',
  `cell_type` varchar(100) DEFAULT NULL,
  `weather1` varchar(200) DEFAULT NULL,
  `weather2` varchar(200) DEFAULT NULL,
  `alarms` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networks`
--

LOCK TABLES `networks` WRITE;
/*!40000 ALTER TABLE `networks` DISABLE KEYS */;
INSERT INTO `networks` VALUES (1,'8.8.8.8','8.8.8.8','cloud.ase-energy.ca','smartcloud.local','RetroSAVE-013',10,'Magellan',0,0,'192.168.2.113','192.168.2.1','255.255.255.0','192.168.1.1','CANNONDALE','dorel13','129.6.15.30','96.226.242.9',0,'','openweathermap.org','',0);
/*!40000 ALTER TABLE `networks` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_networks` AFTER INSERT ON `networks`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'networks'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_networks` AFTER UPDATE ON `networks`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'networks';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_networks` AFTER DELETE ON `networks`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_networks IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'networks';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `severity` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (2,'dmitry@ase-energy.ca',NULL,6),(3,'dmitry@elutsk.com',NULL,3),(26,'','380503173500',3),(29,'','18001212121',2);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_notifications` AFTER INSERT ON `notifications`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_notifications IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'notifications'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_notifications` AFTER UPDATE ON `notifications`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_notifications IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'notifications';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_notifications` AFTER DELETE ON `notifications`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_notifications IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'notifications';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `paramflapdyn`
--

DROP TABLE IF EXISTS `paramflapdyn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paramflapdyn` (
  `device_id` int(11) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `temperature` double(15,3) DEFAULT NULL,
  `airflow` double(15,3) DEFAULT NULL,
  `dimmer` int(11) DEFAULT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paramflapdyn`
--

LOCK TABLES `paramflapdyn` WRITE;
/*!40000 ALTER TABLE `paramflapdyn` DISABLE KEYS */;
/*!40000 ALTER TABLE `paramflapdyn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_paramflapdyn` AFTER INSERT ON `paramflapdyn`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_paramflapdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramflapdyn'; 						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_paramflapdyn` AFTER UPDATE ON `paramflapdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramflapdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramflapdyn';						SET @pk_d_old = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_paramflapdyn` AFTER DELETE ON `paramflapdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramflapdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramflapdyn';						SET @pk_d = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `paramgassensordyn`
--

DROP TABLE IF EXISTS `paramgassensordyn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paramgassensordyn` (
  `device_id` int(11) NOT NULL,
  `pir` int(11) DEFAULT NULL,
  `co2_ppm` int(11) DEFAULT NULL,
  `co_ppm` int(11) DEFAULT NULL,
  `temperature1` float(9,3) DEFAULT NULL,
  `temperature2` float(9,3) DEFAULT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paramgassensordyn`
--

LOCK TABLES `paramgassensordyn` WRITE;
/*!40000 ALTER TABLE `paramgassensordyn` DISABLE KEYS */;
/*!40000 ALTER TABLE `paramgassensordyn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_paramgassensordyn` AFTER INSERT ON `paramgassensordyn`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_paramgassensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramgassensordyn'; 						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_paramgassensordyn` AFTER UPDATE ON `paramgassensordyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramgassensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramgassensordyn';						SET @pk_d_old = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_paramgassensordyn` AFTER DELETE ON `paramgassensordyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramgassensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramgassensordyn';						SET @pk_d = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `paramsensordyn`
--

DROP TABLE IF EXISTS `paramsensordyn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paramsensordyn` (
  `device_id` int(11) NOT NULL,
  `light` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `humidity` double DEFAULT NULL,
  `motion` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paramsensordyn`
--

LOCK TABLES `paramsensordyn` WRITE;
/*!40000 ALTER TABLE `paramsensordyn` DISABLE KEYS */;
INSERT INTO `paramsensordyn` VALUES (16,100,23,70,NULL),(18,339,19,65,NULL),(20,1100,22,63,NULL),(22,2400,17,78,NULL);
/*!40000 ALTER TABLE `paramsensordyn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_paramsensordyn` AFTER INSERT ON `paramsensordyn`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_paramsensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramsensordyn'; 						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_paramsensordyn` AFTER UPDATE ON `paramsensordyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramsensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramsensordyn';						SET @pk_d_old = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @pk_d = CONCAT('<device_id>',NEW.`device_id`,'</device_id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_paramsensordyn` AFTER DELETE ON `paramsensordyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_paramsensordyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'paramsensordyn';						SET @pk_d = CONCAT('<device_id>',OLD.`device_id`,'</device_id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `event_type` int(11) DEFAULT NULL,
  `device_type` int(11) DEFAULT NULL,
  `zigbee_short` int(11) DEFAULT NULL,
  `zigbee_addr64` varchar(32) DEFAULT NULL,
  `zigbee_mode` int(11) DEFAULT NULL,
  `panid` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `rssi` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `device_desc` varchar(255) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `zone_desc` varchar(255) DEFAULT NULL,
  `source` int(11) DEFAULT '0',
  `zigbee_hw` int(11) DEFAULT NULL,
  `zigbee_fw` int(11) DEFAULT NULL,
  `device_hw` int(11) DEFAULT NULL,
  `device_fw` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `asemp_id` int(11) DEFAULT NULL,
  `serial` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

LOCK TABLES `registrations` WRITE;
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
INSERT INTO `registrations` VALUES (1,'2014-04-10 01:01:01',1,1,0,'1122334455667788',2,NULL,NULL,NULL,NULL,NULL,4,NULL,0,NULL,NULL,NULL,NULL,2,NULL,NULL),(2,'2014-04-10 02:02:02',1,0,0,'1122334455667792',2,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,NULL,0,NULL,NULL),(3,'2014-04-10 03:03:03',1,2,0,'1122334455667799',2,NULL,NULL,NULL,NULL,NULL,5,NULL,0,NULL,NULL,NULL,NULL,2,NULL,NULL);
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_registrations` AFTER INSERT ON `registrations`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_registrations IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'registrations'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_registrations` AFTER UPDATE ON `registrations`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_registrations IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'registrations';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_registrations` AFTER DELETE ON `registrations`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_registrations IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'registrations';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `relays`
--

DROP TABLE IF EXISTS `relays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relays` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime NOT NULL,
  `R1` tinyint(4) DEFAULT NULL,
  `R2` tinyint(4) DEFAULT NULL,
  `R3` tinyint(4) DEFAULT NULL,
  `R4` tinyint(4) DEFAULT NULL,
  `R5` tinyint(4) DEFAULT NULL,
  `R6` tinyint(4) DEFAULT NULL,
  `Humidifier` tinyint(4) DEFAULT NULL,
  `W1` tinyint(4) DEFAULT NULL,
  `W2` tinyint(4) DEFAULT NULL,
  `Y1` tinyint(4) DEFAULT NULL,
  `Y2` tinyint(4) DEFAULT NULL,
  `G` tinyint(4) DEFAULT NULL,
  `OB` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relays`
--

LOCK TABLES `relays` WRITE;
/*!40000 ALTER TABLE `relays` DISABLE KEYS */;
INSERT INTO `relays` VALUES (1,'2014-04-06 03:03:03',0,1,0,1,0,0,1,0,1,0,1,0,1),(2,'2014-05-16 01:39:16',0,0,0,0,0,0,1,1,1,0,1,0,0);
/*!40000 ALTER TABLE `relays` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_relays` AFTER INSERT ON `relays`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_relays IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'relays'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_relays` AFTER UPDATE ON `relays`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_relays IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'relays';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_relays` AFTER DELETE ON `relays`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_relays IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'relays';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id_session` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `opened` datetime NOT NULL,
  `expires` datetime NOT NULL,
  `type` int(11) NOT NULL,
  `dbid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_session`),
  UNIQUE KEY `id_session` (`id_session`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smartdevices`
--

DROP TABLE IF EXISTS `smartdevices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smartdevices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated` datetime DEFAULT NULL,
  `type_` int(11) DEFAULT NULL,
  `interface` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `relay` int(11) DEFAULT NULL,
  `alarm` int(11) NOT NULL DEFAULT '0',
  `severity` int(11) DEFAULT NULL,
  `maker` varchar(200) DEFAULT NULL,
  `model` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smartdevices`
--

LOCK TABLES `smartdevices` WRITE;
/*!40000 ALTER TABLE `smartdevices` DISABLE KEYS */;
INSERT INTO `smartdevices` VALUES (1,'2014-05-12 21:05:20',0,2,'11223344',4,1,1,'Test manufacturer','Test model','Some test device'),(2,'2014-05-13 11:28:19',1,4,'21322323',6,0,2,'test mfc','test modell','another test device');
/*!40000 ALTER TABLE `smartdevices` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_smartdevices` AFTER INSERT ON `smartdevices`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_smartdevices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartdevices'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_smartdevices` AFTER UPDATE ON `smartdevices`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartdevices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartdevices';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_smartdevices` AFTER DELETE ON `smartdevices`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartdevices IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartdevices';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `smartsensors`
--

DROP TABLE IF EXISTS `smartsensors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smartsensors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime NOT NULL,
  `type_` int(11) DEFAULT NULL,
  `froom_t` decimal(6,1) DEFAULT NULL,
  `froom_h` int(11) DEFAULT NULL,
  `co` int(11) DEFAULT NULL,
  `co2` int(11) DEFAULT NULL,
  `t_int` decimal(6,1) DEFAULT NULL,
  `t_supply_duct` decimal(6,1) DEFAULT NULL,
  `t_return_duct` decimal(6,1) DEFAULT NULL,
  `h_supply_duct` int(11) DEFAULT NULL,
  `h_return_duct` int(11) DEFAULT NULL,
  `htu` decimal(6,2) DEFAULT NULL,
  `air_vel` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smartsensors`
--

LOCK TABLES `smartsensors` WRITE;
/*!40000 ALTER TABLE `smartsensors` DISABLE KEYS */;
INSERT INTO `smartsensors` VALUES (1,'2014-04-06 01:01:01',0,25.0,70,2,333,35.0,NULL,NULL,NULL,NULL,NULL,NULL),(2,'2014-04-06 02:02:02',0,24.0,72,2,321,34.0,NULL,NULL,NULL,NULL,NULL,NULL),(3,'2014-04-07 01:01:01',0,26.0,71,1,321,36.0,14.0,23.0,55,67,NULL,NULL),(4,'2014-05-01 13:32:44',0,27.0,66,1,339,33.0,17.0,25.0,65,70,55.00,4);
/*!40000 ALTER TABLE `smartsensors` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_smartsensors` AFTER INSERT ON `smartsensors`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_smartsensors IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartsensors'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_smartsensors` AFTER UPDATE ON `smartsensors`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartsensors IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartsensors';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_smartsensors` AFTER DELETE ON `smartsensors`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartsensors IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartsensors';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `smartstatus`
--

DROP TABLE IF EXISTS `smartstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smartstatus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime NOT NULL,
  `group_` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smartstatus`
--

LOCK TABLES `smartstatus` WRITE;
/*!40000 ALTER TABLE `smartstatus` DISABLE KEYS */;
INSERT INTO `smartstatus` VALUES (1,'2014-07-18 20:54:03','health','cpu','1.10, 1.18, 1.01'),(2,'2014-07-18 20:54:03','health','ram','285Mb used, 154Mb free'),(3,'2014-07-18 20:54:03','health','disk','2250Mb used, 1359Mb free'),(4,'2014-07-18 20:54:03','health','uptime','27 min'),(5,'2014-07-18 20:54:03','network','ip_main','192.168.2.17'),(6,'2014-07-18 20:54:03','network','gateway','192.168.2.1'),(7,'2014-07-18 20:54:04','network','ip_wan','10.0.0.1'),(8,'2014-04-23 20:06:00','network','cloud','cloud.ase-energy.ca'),(9,'2014-05-01 17:09:34','network','ip_cwan',NULL),(10,'2014-05-01 17:10:05','network','gw_cwan',NULL),(11,'2014-07-18 20:54:04','network','list_wan',''),(12,'2014-07-18 20:54:04','network','dns','8.8.8.8;8.8.4.4'),(13,'2014-07-18 20:27:53','weather','location','Montreal'),(14,'2014-07-18 20:27:53','weather','temp','25.68'),(15,'2014-07-18 20:27:53','weather','humid','66'),(16,'2014-07-18 20:27:53','weather','wind','2.57 270'),(17,'2014-07-18 20:27:53','weather','air_pres','1018'),(18,'2014-07-18 20:27:53','weather','cond','Clouds, few clouds');
/*!40000 ALTER TABLE `smartstatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_smartstatus` AFTER INSERT ON `smartstatus`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_smartstatus IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartstatus'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_smartstatus` AFTER UPDATE ON `smartstatus`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartstatus IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartstatus';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_smartstatus` AFTER DELETE ON `smartstatus`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_smartstatus IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'smartstatus';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `statistics`
--

DROP TABLE IF EXISTS `statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistics` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `data` datetime NOT NULL,
  `sim_id` int(11) NOT NULL DEFAULT '0',
  `zone_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `report_type` tinyint(4) DEFAULT '0',
  `T` float(9,3) NOT NULL DEFAULT '0.000',
  `H` float(9,3) NOT NULL DEFAULT '0.000',
  `L` float(9,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `sim_id` (`sim_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistics`
--

LOCK TABLES `statistics` WRITE;
/*!40000 ALTER TABLE `statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistics` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_statistics` AFTER INSERT ON `statistics`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_statistics IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'statistics'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_statistics` AFTER UPDATE ON `statistics`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_statistics IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'statistics';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_statistics` AFTER DELETE ON `statistics`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_statistics IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'statistics';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `temperaturebreakout`
--

DROP TABLE IF EXISTS `temperaturebreakout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temperaturebreakout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `temperature_profile_id` int(11) NOT NULL,
  `dayofweek` int(11) NOT NULL,
  `timeframe` int(11) NOT NULL,
  `temperature` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temperaturebreakout`
--

LOCK TABLES `temperaturebreakout` WRITE;
/*!40000 ALTER TABLE `temperaturebreakout` DISABLE KEYS */;
INSERT INTO `temperaturebreakout` VALUES (1,1,0,0,20),(2,1,0,30,20),(3,1,0,100,20),(4,1,0,130,20),(5,1,0,200,20),(6,1,0,230,20),(7,1,0,300,20),(8,1,0,330,20),(9,1,0,400,20),(10,1,0,430,20),(11,1,0,500,20),(12,1,0,530,20),(13,1,0,600,20),(14,1,0,630,20),(15,1,0,700,20),(16,1,0,730,20),(17,1,0,800,20),(18,1,0,830,20),(19,1,0,900,20),(20,1,0,930,20),(21,1,0,1000,20),(22,1,0,1030,20),(23,1,0,1100,20),(24,1,0,1130,20),(25,1,0,1200,20),(26,1,0,1230,20),(27,1,0,1300,20),(28,1,0,1330,20),(29,1,0,1400,20),(30,1,0,1430,20),(31,1,0,1500,20),(32,1,0,1530,20),(33,1,0,1600,20),(34,1,0,1630,20),(35,1,0,1700,20),(36,1,0,1730,20),(37,1,0,1800,20),(38,1,0,1830,20),(39,1,0,1900,20),(40,1,0,1930,20),(41,1,0,2000,20),(42,1,0,2030,20),(43,1,0,2100,20),(44,1,0,2130,20),(45,1,0,2200,20),(46,1,0,2230,20),(47,1,0,2300,20),(48,1,0,2330,20);
/*!40000 ALTER TABLE `temperaturebreakout` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_temperaturebreakout` AFTER INSERT ON `temperaturebreakout`
	FOR EACH ROW BEGIN 
IF (@DISABLE_TRIGGER_temperaturebreakout IS NULL) THEN
	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 
	SET @tbl_name = 'temperaturebreakout'; 
	SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 
	SET @rec_state = 1;
	DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 
	INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 
	VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 
END IF;
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_temperaturebreakout` AFTER UPDATE ON `temperaturebreakout`
	FOR EACH ROW BEGIN
IF (@DISABLE_TRIGGER_temperaturebreakout IS NULL) THEN
	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 
	SET @tbl_name = 'temperaturebreakout';
	SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');
	SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');
	SET @rec_state = 2;
	SET @rs = 0;
	SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;
	IF @rs = 0 THEN 
	INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );
	ELSE 
	UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;
	END IF; 
END IF;
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_temperaturebreakout` AFTER DELETE ON `temperaturebreakout`
	FOR EACH ROW BEGIN
IF (@DISABLE_TRIGGER_temperaturebreakout IS NULL) THEN
	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 
	SET @tbl_name = 'temperaturebreakout';
	SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');
	SET @rec_state = 3;
	SET @rs = 0;
	SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;
	DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 
	IF @rs <> 1 THEN 
	INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 
	END IF; 
END IF;
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `temperatureprofile`
--

DROP TABLE IF EXISTS `temperatureprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temperatureprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `temperature` double NOT NULL,
  `humidity` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temperatureprofile`
--

LOCK TABLES `temperatureprofile` WRITE;
/*!40000 ALTER TABLE `temperatureprofile` DISABLE KEYS */;
INSERT INTO `temperatureprofile` VALUES (1,'Default',20,60),(2,'Make me hotter',22,70),(3,'Cool me down',18,50),(4,'Virtual zone',0,0);
/*!40000 ALTER TABLE `temperatureprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_temperatureprofile` AFTER INSERT ON `temperatureprofile`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_temperatureprofile IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'temperatureprofile'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_temperatureprofile` AFTER UPDATE ON `temperatureprofile`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_temperatureprofile IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'temperatureprofile';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_temperatureprofile` AFTER DELETE ON `temperatureprofile`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_temperatureprofile IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'temperatureprofile';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `thermostat`
--

DROP TABLE IF EXISTS `thermostat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thermostat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `updated` datetime NOT NULL,
  `W1` tinyint(4) NOT NULL DEFAULT '0',
  `W2` tinyint(4) NOT NULL DEFAULT '0',
  `Y1` tinyint(4) NOT NULL DEFAULT '0',
  `Y2` tinyint(4) NOT NULL DEFAULT '0',
  `G` tinyint(4) NOT NULL DEFAULT '0',
  `OB` tinyint(4) NOT NULL DEFAULT '0',
  `avg_t` decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thermostat`
--

LOCK TABLES `thermostat` WRITE;
/*!40000 ALTER TABLE `thermostat` DISABLE KEYS */;
INSERT INTO `thermostat` VALUES (1,'2014-04-06 04:04:04',1,1,0,0,1,1,NULL),(2,'2014-04-06 05:05:05',0,0,1,1,0,1,NULL),(3,'2014-05-08 20:53:08',1,1,0,0,0,0,26.20);
/*!40000 ALTER TABLE `thermostat` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_thermostat` AFTER INSERT ON `thermostat`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_thermostat IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'thermostat'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_thermostat` AFTER UPDATE ON `thermostat`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_thermostat IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'thermostat';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_thermostat` AFTER DELETE ON `thermostat`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_thermostat IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'thermostat';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ui_menu`
--

DROP TABLE IF EXISTS `ui_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ui_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menu` varchar(30) DEFAULT NULL,
  `submenu` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  `access` tinyint(4) NOT NULL DEFAULT '0',
  `level` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_menu`
--

LOCK TABLES `ui_menu` WRITE;
/*!40000 ALTER TABLE `ui_menu` DISABLE KEYS */;
INSERT INTO `ui_menu` VALUES (1,'status','relays','Status',0,0),(2,'status','relays','Smart Controller',0,1),(3,'status','onboard','Onboard Sensors',0,1),(4,'status','indoor','Indoor Sensors',0,1),(5,'status','outdoor','Outdoor Sensors',0,1),(6,'status','system','System Information',0,1),(7,'networks','ip','Networks',0,0),(8,'networks','ip','IP Network',0,1),(9,'networks','zigbee','Local Zigbee',0,1),(10,'networks','asemp','ASEMP Profile',0,1),(11,'hvac','furnace','HVAC',0,0),(12,'hvac','furnace','Furnace',0,1),(13,'hvac','fblower','Furnace Blower',0,1),(14,'hvac','acheat','A/C & Heat Pump',0,1),(15,'hvac','hrverv','HRV/ERV Control',0,1),(16,'hvac','comfort','Comfort Settings',0,1),(17,'hvac','thermostat','Customer Thermostat Control',0,1),(18,'smartgrid','peaksaver','Smart Grid',0,0),(20,'zonedev','zones','Devices Config<br>& Management',0,0),(21,'events','events','Events<br>& Alarms',0,0),(22,'userinfo','details','Customer<br>Settings',0,0),(23,'userinfo','details','User Details',0,1),(24,'userinfo','alarms','Alarms & Events',0,1),(25,'userinfo','password','Password',0,1),(26,'system','update','System<br>Maintenance',0,0),(28,'system','update','Software Update',0,1),(29,'system','db','Database Maintenance',0,1),(32,'zonedev','zones','Zones Management',0,1),(33,'zonedev','devices','Remote Device Config',0,1),(34,'zonedev','newdev','Add New Devices',0,1),(39,'events','events','Alarms & Events Viewer',0,1),(40,'events','alarms','RetroSAVE Alarms Management',0,1),(41,'status','networks','Network Connections',0,1),(43,'events','management','Networks Alarms Management',0,1),(44,'smartgrid','peaksaver','PeakSaver',0,1),(45,'smartgrid','smartmeter','SmartMeter',0,1),(46,'reports','occupancy','Reports',0,0),(47,'logout','logout','Logout',0,0),(48,'reports','occupancy','Statistical Occupancy Stats',0,1),(49,'reports','retrosave','RetroSAVE Runtime',0,1),(50,'reports','charts','Charts',0,1),(51,'reports','savings','Savings',0,1),(52,'reports','runtime','HVAC Runtime',0,1),(54,'status','zigbee','Zigbee',0,1),(55,'reports','cots','COTS Thermostat Stats',0,1),(56,'zonedev','smartdevices','Smart Controller Local Sensors & Controls',0,1);
/*!40000 ALTER TABLE `ui_menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_ui_menu` AFTER INSERT ON `ui_menu`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_ui_menu IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'ui_menu'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_ui_menu` AFTER UPDATE ON `ui_menu`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_ui_menu IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'ui_menu';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_ui_menu` AFTER DELETE ON `ui_menu`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_ui_menu IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'ui_menu';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name1` varchar(100) NOT NULL,
  `name2` varchar(100) DEFAULT NULL,
  `address1` varchar(200) DEFAULT NULL,
  `address2` varchar(200) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postal` varchar(20) DEFAULT NULL,
  `phone1` varchar(20) NOT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `phone3` varchar(20) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `timezone` tinyint(4) NOT NULL DEFAULT '0',
  `comfort` tinyint(4) NOT NULL DEFAULT '0',
  `access` tinyint(4) NOT NULL DEFAULT '0',
  `t_display` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'aseuser','aseuser','Dmitry','','','','','CAN-PE','Armenia','','380503173500','','','dmitry@ase-energy.ca',5,2,0,0),(2,'aseadmin','aseadmin','Dmitry','Ilchyshyn','Somewhere 3','','Montreal','NONE','Canada','10000','380503173500','','','dmitry@ase-energy.ca',33,2,1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_users` AFTER INSERT ON `users`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_users IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'users'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_users` AFTER UPDATE ON `users`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_users IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'users';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_users` AFTER DELETE ON `users`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_users IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'users';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `zigbee`
--

DROP TABLE IF EXISTS `zigbee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zigbee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `channel` int(11) DEFAULT NULL,
  `panid` int(11) DEFAULT NULL,
  `panid_sel` tinyint(4) NOT NULL DEFAULT '1',
  `addr64` varchar(32) NOT NULL,
  `addr16` varchar(16) NOT NULL,
  `encryption` tinyint(4) DEFAULT '1',
  `sec_key` varchar(100) DEFAULT NULL,
  `mfc_id` varchar(100) DEFAULT NULL,
  `hw_version` varchar(100) DEFAULT NULL,
  `sw_version` varchar(100) DEFAULT NULL,
  `alarms` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zigbee`
--

LOCK TABLES `zigbee` WRITE;
/*!40000 ALTER TABLE `zigbee` DISABLE KEYS */;
INSERT INTO `zigbee` VALUES (1,7,4321,1,'0013A200406665F0','0000',1,'sometestkey2','XBP24BZ7PITB','XBEEPRO2','v1347',0);
/*!40000 ALTER TABLE `zigbee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_zigbee` AFTER INSERT ON `zigbee`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zigbee'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_zigbee` AFTER UPDATE ON `zigbee`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zigbee';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_zigbee` AFTER DELETE ON `zigbee`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zigbee IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zigbee';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `zoneadvanced`
--

DROP TABLE IF EXISTS `zoneadvanced`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zoneadvanced` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL,
  `type_` int(11) NOT NULL,
  `realvar1` float(9,3) DEFAULT NULL,
  `realvar2` float(9,3) DEFAULT NULL,
  `realvar3` float(9,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zone_id` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zoneadvanced`
--

LOCK TABLES `zoneadvanced` WRITE;
/*!40000 ALTER TABLE `zoneadvanced` DISABLE KEYS */;
/*!40000 ALTER TABLE `zoneadvanced` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_zoneadvanced` AFTER INSERT ON `zoneadvanced`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_zoneadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zoneadvanced'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_zoneadvanced` AFTER UPDATE ON `zoneadvanced`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zoneadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zoneadvanced';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_zoneadvanced` AFTER DELETE ON `zoneadvanced`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zoneadvanced IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zoneadvanced';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `zones`
--

DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `temperature_profile_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `volume` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `temperature_profile_id` (`temperature_profile_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones`
--

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES (2,0,'Master zone',0),(1,0,'Temporary zone',0),(3,1,'Living room',40),(4,1,'Kitchen',30),(6,0,'Outdoor area',0),(5,1,'Hall is biig',50),(14,1,'antoine',1),(19,1,'Some test zone 2',1),(17,1,'Some test zone 1',1);
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_zones` AFTER INSERT ON `zones`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_zones IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zones'; 						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_zones` AFTER UPDATE ON `zones`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zones IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zones';						SET @pk_d_old = CONCAT('<id>',OLD.`id`,'</id>');						SET @pk_d = CONCAT('<id>',NEW.`id`,'</id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_zones` AFTER DELETE ON `zones`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zones IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zones';						SET @pk_d = CONCAT('<id>',OLD.`id`,'</id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `zonesdyn`
--

DROP TABLE IF EXISTS `zonesdyn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zonesdyn` (
  `zone_id` int(11) NOT NULL,
  `occupation` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  `timer_on` int(11) DEFAULT '0',
  `timer_off` int(11) DEFAULT '0',
  `priority` int(11) DEFAULT '0',
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zonesdyn`
--

LOCK TABLES `zonesdyn` WRITE;
/*!40000 ALTER TABLE `zonesdyn` DISABLE KEYS */;
INSERT INTO `zonesdyn` VALUES (3,2,0,0,0,0),(4,0,0,0,0,0),(5,1,0,0,0,0),(14,0,0,0,0,0),(17,0,0,0,0,0),(19,0,0,0,0,0);
/*!40000 ALTER TABLE `zonesdyn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_i_zonesdyn` AFTER INSERT ON `zonesdyn`						FOR EACH ROW BEGIN 					IF (@DISABLE_TRIGGER_zonesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zonesdyn'; 						SET @pk_d = CONCAT('<zone_id>',NEW.`zone_id`,'</zone_id>'); 						SET @rec_state = 1;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`,`record_state` ) 						VALUES (@time_mark, @tbl_name, @pk_d, @pk_d, @rec_state); 					END IF;	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_u_zonesdyn` AFTER UPDATE ON `zonesdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zonesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zonesdyn';						SET @pk_d_old = CONCAT('<zone_id>',OLD.`zone_id`,'</zone_id>');						SET @pk_d = CONCAT('<zone_id>',NEW.`zone_id`,'</zone_id>');						SET @rec_state = 2;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						IF @rs = 0 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d_old, @rec_state );						ELSE 						UPDATE `history_store` SET `timemark` = @time_mark, `pk_date_src` = @pk_d WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d_old;						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `a_d_zonesdyn` AFTER DELETE ON `zonesdyn`						FOR EACH ROW BEGIN					IF (@DISABLE_TRIGGER_zonesdyn IS NULL) THEN	SET @time_mark = DATE_ADD(NOW(), INTERVAL 0 SECOND); 						SET @tbl_name = 'zonesdyn';						SET @pk_d = CONCAT('<zone_id>',OLD.`zone_id`,'</zone_id>');						SET @rec_state = 3;						SET @rs = 0;						SELECT `record_state` INTO @rs FROM `history_store` WHERE  `table_name` = @tbl_name AND `pk_date_src` = @pk_d;						DELETE FROM `history_store` WHERE `table_name` = @tbl_name AND `pk_date_src` = @pk_d; 						IF @rs <> 1 THEN 						INSERT INTO `history_store`( `timemark`, `table_name`, `pk_date_src`,`pk_date_dest`, `record_state` ) VALUES (@time_mark, @tbl_name, @pk_d,@pk_d, @rec_state ); 						END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-18 20:54:58
